//pipe generada asi: 
//                  ng generate pipe redondear --flat --skip-tests --standalone

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'redondear'
})
export class RedondearPipe implements PipeTransform {

  transform(value: number, numdecimales:number): number {
      return Math.round(value * Math.pow(10,numdecimales))/Math.pow(10,numdecimales)

  }

}
