import { Component, effect, inject, Injector, signal, Signal, viewChild } from '@angular/core';
import { FormsModule, NgModel } from '@angular/forms';
import { Router, RouterModule} from '@angular/router'

import { RestClientService } from '../../../servicios/rest-client.service';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';

@Component({
  selector: 'app-login',
  imports: [RouterModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  //---- propiedades componente ---
  public creds:{ email:string, password: string }={ email:'', password:''};
  public mensajesError=signal<string>(''); //<--------- señal para mostrar mensajes de error del servicio de login
  
  public emailNgModelLink=viewChild<NgModel>('email'); //<---- hago referencia a esta variable template: #email="ngModel" ( la directiva NgModel en su definicion tiene una prop detnro decorador @Directive que es exportas:'ngModel' q permite q sea referenciada por variable templante, sino imposible) https://angular.dev/guide/templates/variables#assigning-a-reference-to-an-angular-directive
                                                      //  q genera un FormControl para la prop.modelo creds.email y asi puedo ponerle validadodres desde codigo y ver su estado de valiacion (sobre todo asincrons)
  public passwordNgModelLink=viewChild<NgModel>('password');

  //----- inyeccion servicios ---

  private _router:Router=inject(Router);
  private _restSvc:RestClientService=inject(RestClientService);
  private _injector=inject(Injector);
   private _storageGlobal=inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);
  
  constructor(){
        
    effect(
      ()=>{
        this.emailNgModelLink()?.control.addAsyncValidators( [ ] ); // <-------- añado validadores a FormControl creado por directiva NgModel a elementos <input... si me interesa
      }
    )

  }
  
  ContinuarLogin() {
    console.log('creds...', this.creds);
    const _resp=this._restSvc.LoginRegistroCliente(this.creds, 'Login') ; 
    effect(
      ()=>{
        //console.log('respuesta recibida del server...', _resp());
        if(_resp().codigo===0){
            //---meter este codigo en valildacion 2fa ----
            console.log('CODIGO DE VALIDACION 2FA...', _resp().datos.codigo);
            
            //almacenar en servicio global valores del codigo 2fa, email y jwtVerificacion...
            this._storageGlobal.setCodigoVerificacion(_resp().datos.codigo);
            this._storageGlobal.setJwt('verificacion', _resp().datos.jwtVerificacion );
            this._storageGlobal.setDatosCliente( _resp().datos.datosCliente );

          //redirigir a componente VERIFICACION CODIGO 2fa mandado por mail...
          this._router.navigateByUrl('/Cliente/Verificar/Login');
      } else {
        //mostramos mensaje de error en vista....
        this.mensajesError.set(_resp().mensaje)
        
      }
      },{ injector: this._injector}
    )    
    

  }

  GotoRegistro() {
    this._router.navigateByUrl('/Cliente/Registro');
  }

}
