import { Component, inject, signal } from '@angular/core';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';
import ICliente from '../../../modelos/interfaces_orm/ICliente';
import { JsonPipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio-panel',
  imports: [JsonPipe],
  templateUrl: './inicio-panel.component.html',
  styleUrl: './inicio-panel.component.css'
})
export class InicioPanelComponent {

   private _storageGlobal=inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);
   private _router=inject(Router);
    
  datosCliente=signal<ICliente|undefined>(this._storageGlobal.getDatosCliente());

  IrATienda() {
    this._router.navigateByUrl('/');
  }
}
