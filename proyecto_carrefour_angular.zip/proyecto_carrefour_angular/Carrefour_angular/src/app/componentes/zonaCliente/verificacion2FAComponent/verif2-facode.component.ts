import { Component, effect, inject, Injector, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';
import { RestClientService } from '../../../servicios/rest-client.service';

@Component({
  selector: 'app-verif2-facode',
  imports: [],
  templateUrl: './verif2-facode.component.html',
  styleUrl: './verif2-facode.component.css'
})
export class Verif2FACodeComponent {

  operacion=signal<string>('');
  codigoChars=signal<string[]>(Array.from({length:6}, _ => '')); //<---- array para almacenar caracteres introducidos en las cajitas de texto del codigo de verific.

  private _codigo:string='';
  private _jwt:string='';

  //---- injeccion de servicios ----
  private activatedRoute:ActivatedRoute=inject(ActivatedRoute);
  private restClient:RestClientService=inject(RestClientService);
  private _storageGlobal=inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);
  private _injector=inject(Injector);
  private _router=inject(Router);

  constructor(){
    this.operacion.set(this.activatedRoute.snapshot.paramMap.get('operacion')||'')

    // this._codigo=this._storageGlobal.getCodigoVerificacion();
    // this._jwt=this._storageGlobal.getJWT()!.verificacion;
    // console.log('codigo y jwt verificacion recuperados del servicio...', this._codigo, this._jwt);

  }

  PushValue($event: Event, a: number){
    //console.log('valores parametros...', ($event.target as any).value, a);
    
    //tengo q  meter en array almacenado en la señal codigoChars el nuevo caracter, partiendo del array
    //q existia previamente (no lo puedo mutar)
    // nooooooooops, no funciona bien..---> this.codigoChars.update( prev => ([...prev, [a]=($event.target as any).value]) ); 
    this.codigoChars.update( prev => prev.map( (el,pos,arr)=> pos==a-1 ? ($event.target as any).value : el ) );
    //console.log('array de caracteres ...hasta ahora: ', this.codigoChars());
  }

  async ValidarCodigo(){
    const _codigoIntroducido:string=this.codigoChars().join('');

    let _resp=await this.restClient.VerificarCodigo(
                  this.operacion(),
                  _codigoIntroducido,
                  this._jwt,
                  this._storageGlobal.getDatosCliente()!.cuenta.email
                );
   effect(
    ()=>{
        if(_resp().codigo==0){
            //redirijo al usuario  establezco los tokens de sesion y refresh en el storage y datos del cliente
            this._storageGlobal.setDatosCliente( _resp().datos.datosCliente );
            
            this._storageGlobal.setJwt('sesion', _resp().datos.sesion);
            this._storageGlobal.setJwt('refresh', _resp().datos.refresh);
            this._storageGlobal.setJwt('verificacion', _resp().datos.verificacion);

            this._router.navigateByUrl('/');
        } else {
          //mostrar fallos de verificacion de codigo en vista    
        }
    }, { injector: this._injector }
   )                
  }
}
