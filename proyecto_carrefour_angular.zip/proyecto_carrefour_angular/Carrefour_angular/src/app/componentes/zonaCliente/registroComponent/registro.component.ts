import { AsyncPipe, JsonPipe } from '@angular/common';
import { Component, effect, inject, Injector, Signal, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Router,RouterModule } from '@angular/router';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms'

import { RestClientService } from '../../../servicios/rest-client.service';
import IRestMessage from '../../../modelos/IRestMessage';
import { StorageGlobalService } from '../../../servicios/storage-global.service';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';

type IDatosForm={
  nombre?:    string,
  apellidos?: string,
  telefono?:  string,
  dninif?:    string,
  tipoDocumento?: string,
  email?:     string,
  password?:  string,
  repassword?:string,
  cp?:        string
}

@Component({
  selector: 'app-registro',
  imports: [ ReactiveFormsModule,RouterModule, JsonPipe ], //AsyncPipe
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.css'
})
export class RegistroComponent {

  //#region--------------------- propiedades de componente ------------------------------------------------
  passVisible=signal<boolean>(false);
  repassVisible=signal<boolean>(false);
  formRegistro:FormGroup;
  valoresFormRegistro:Signal<IDatosForm>;
  mensajesError=signal<string>(''); //<--------- señal para mostrar mensajes de error del servicio de registro
  //#endregion

  //#region --------------------- solicitud injeccion de servicios , ... al DI -----------------------------
  //private _injector=inject(Injector); <------ servicio Injector por si usas metodo toSignal, toObservable, ... fuera de constructor
  private _restSvc:RestClientService=inject(RestClientService);
  private _router:Router = inject(Router);
  private _injector=inject(Injector);
  private _storageGlobal=inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);

  //#endregion -------------------------------------------------------------------------------------------------


  constructor(){
      this.formRegistro=new FormGroup(
        {
           nombre: new FormControl('',[ Validators.required, Validators.maxLength(100), Validators.minLength(3) ]),
           apellidos: new FormControl('',[ Validators.required,Validators.maxLength(200), Validators.minLength(3) ]),
           telefono: new FormControl('',[ Validators.required, Validators.pattern('^\\(?\\+?\\d{2}\\)?\\d{9}$') ]),
           tipoDocumento: new FormControl('DNI',[Validators.required]),
           dninif: new FormControl('',[ Validators.required ]),
           email: new FormControl('', [ Validators.required, Validators.email ]),
           password: new FormControl('', [ Validators.required ] ),
           repassword: new FormControl('', [ Validators.required ] ),
           cp: new FormControl('')           
        }
      );

      this.valoresFormRegistro=toSignal( this.formRegistro.valueChanges ) //, { injector: this._injector } ) <---- solo si ejecutas metodo toSignal fuera del constructor
         
    } 

  //#region ------------------------ metodos del componente -------------------------------------------------------
  RegistrarCliente($event: any) {
    console.log('metodo disparado por directiva formGroup q provoca submit del <form...>, los datos del evento son: ', $event);
    console.log('los datos del formulario son: ', this.formRegistro.value)

    const _resp=this._restSvc.LoginRegistroCliente(this.valoresFormRegistro(), 'Registro');
    effect(
      ()=>{
        console.log('respuesta del server al servicio en registro...', _resp());

        if(_resp().codigo===0){
            //almacenar en servicio global valores del codigo 2fa, email y jwtVerificacion...
            this._storageGlobal.setCodigoVerificacion(_resp().datos.codigo);
            this._storageGlobal.setJwt('verificacion', _resp().datos.jwtVerificacion );
            this._storageGlobal.setDatosCliente( _resp().datos.datosCliente );

            //redirigir a componente VERIFICACION CODIGO 2fa mandado por mail...
            this._router.navigateByUrl('/Cliente/Verificar/Registro');
        } else {
          //mostramos mensaje de error en vista....
          this.mensajesError.set( _resp().mensaje );
        }
      }, { injector: this._injector}

    )
    

  }



  SetRePassVisible() {
    this.repassVisible.set( ! this.repassVisible() );
  }
  SetPassVisible() {
    this.passVisible.set( ! this.passVisible() );
  }

  ValidarFormatoDniNif() {
     const _dninif=this.formRegistro.controls['dninif'].value;

  }
//#endregion ------------------------------------------------------------------------------------------------------

}
