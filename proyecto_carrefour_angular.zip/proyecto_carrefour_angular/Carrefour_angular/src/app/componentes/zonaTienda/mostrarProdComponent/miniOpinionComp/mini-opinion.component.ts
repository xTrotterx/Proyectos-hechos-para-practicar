import { Component, Input } from '@angular/core';
import IOpinion from '../../../../modelos/interfaces_orm/IOpinion';

@Component({
  selector: 'app-mini-opinion',
  imports: [],
  templateUrl: './mini-opinion.component.html',
  styleUrl: './mini-opinion.component.css'
})
export class MiniOpinionComponent {

@Input() opinion!: IOpinion;

}
