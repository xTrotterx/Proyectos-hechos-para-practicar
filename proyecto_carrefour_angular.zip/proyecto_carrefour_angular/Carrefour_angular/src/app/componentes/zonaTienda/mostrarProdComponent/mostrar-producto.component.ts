import { Component, computed, inject, Injector, Renderer2, Resource, resource, ResourceRef, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import IRestMessage from '../../../modelos/IRestMessage';
import { RestClientService } from '../../../servicios/rest-client.service';
import IProducto from '../../../modelos/interfaces_orm/IProducto';
import { MiniOpinionComponent } from './miniOpinionComp/mini-opinion.component';
import { ModalOpinionComponent } from './modalOpinionComp/modal-opinion.component';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';
import IOpinion from '../../../modelos/interfaces_orm/IOpinion';
import ICliente from '../../../modelos/interfaces_orm/ICliente';


@Component({
  selector: 'app-mostrar-producto',
  imports: [MiniOpinionComponent, ModalOpinionComponent],
  templateUrl: './mostrar-producto.component.html',
  styleUrl: './mostrar-producto.component.css'
})
export class MostrarProductoComponent {
  //servicios a injectar
  private _injector = inject(Injector);
  private _activatedRoute = inject(ActivatedRoute);
  private _router = inject(Router);
  private _storage = inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);

  //recuperarProducto con funcion Resource
 private _idProd=signal<string>(this._activatedRoute.snapshot.paramMap.get('idProducto') as string);

  private _productoResource: Resource<IRestMessage>=resource(
    {
      request: this._idProd,
      loader: async ( {request, abortSignal, previous } )=>{
        console.log('valor de parametros ResourceLoaderParams de la funcion loader...', request, abortSignal, previous);
        console.log('valor de la señal', this._idProd())//me pilla bien el id del producto pero en node me lo pone como undefined
        let _resp=await fetch(
                              `http://localhost:3003/api/zonaTienda/Producto?idProducto=${this._idProd()}`,
                               { method: 'GET', signal: abortSignal }
                              );
        let _body=await _resp.json();
        return _body ?? { codigo:400, mensaje:'...error al recuperar producto....'} 
      },
      injector: this._injector
    }
  );

   public producto = computed<IProducto | null>(() => {
    let _resp = this._productoResource.value();
    if (_resp?.codigo !== 0) return null;
    return _resp.datos;
  });



  // Para poner la valoracion media
  public valoracionMedia = computed<number>(() => {
    const _opiniones = this.opiniones();
    if (_opiniones.length === 0) return 0;
    const total = _opiniones.reduce((sum, op) => sum + (op.estrellas ?? 0), 0);
    return total;
  });

   //metodo para comprobar si el cliente esta logueado y no tiene valoracion sobre ese producto
  /* no funciona me redirije al login pero se habre el modal
public comprobarCliente() {
     
  let _cliente: ICliente | null = this._storage.getDatosCliente() as ICliente
      //id del cliente de mongo, tengo que cambiarlo
     let _idCliente = '67e1efd1fd6a52f623c9e52a';

      //no puede continuar si no esta logueado o si ya ha hecho una valoracion de este producto
      if (!_cliente || this.opiniones().some(op => op.idCliente === _idCliente)) {
        this._router.navigateByUrl('/zonaCliente/Login');
      }
  }
      */

  //recupero de node las opiniones pasandole el id del producot
  private _opinionesResource: Resource<IRestMessage> =resource(
    {
      request: this._idProd,
      loader:async ({request, abortSignal, previous} )=>{
        console.log('valor del idproducto que voy a pasar a node', this._idProd())
        let _resp =await fetch(
                                `http://localhost:3003/api/zonaTienda/RecuperarOpiniones?idProducto=${this._idProd()}`,
                                {method:'GET', signal:abortSignal}
                              );
        let _body =await _resp.json();
        console.log('opiniones', _body)
        return _body ?? {codigo:400, mensaje:'...error al recuperar opiniones....'}
      },
      injector: this._injector
    })

  //public opiniones=computed<IOpinion[]>( ()=> this._opinionesResource.value() ?  (this._opinionesResource.value().codigo==0 ? this._opinionesResource.value().datos : [] ): [] )

  public opiniones = computed<IOpinion[] >(() => {
    let _resp = this._opinionesResource.value();
    if (_resp?.codigo === 0 ) {
      console.log('datitot',_resp.datos);
      return _resp.datos;
    }
    return [];
  });


  public _opciones = signal<'fecha' | 'megusta ' | 'puntuacion' |'todas'>('todas');

  public listarOpiniones = computed<IOpinion[]>(() => {
    const _opinionesArray=[...this.opiniones()]
    switch(this._opciones()){
      case'fecha':return _opinionesArray.sort((a,b) =>(b.fechCreacion ?? '') > (a.fechCreacion ?? '') ? 1 : -1);

      case 'megusta ': return _opinionesArray.sort((a, b) => (b.tipo ?? 0) - (a.tipo ?? 0)); 

      case 'puntuacion':return _opinionesArray.sort((a, b) => (b.estrellas ?? 0) - (a.estrellas ?? 0));

      default:
        return _opinionesArray
    }
    });


   
  
}
