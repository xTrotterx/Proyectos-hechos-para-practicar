import { Component, computed, ElementRef, inject, Injector, Renderer2, Resource, resource, signal, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import IRestMessage from '../../../../modelos/IRestMessage';
import IProducto from '../../../../modelos/interfaces_orm/IProducto';
import IOpinion from '../../../../modelos/interfaces_orm/IOpinion';

@Component({
  selector: 'app-modal-opinion',
  imports: [],
  templateUrl: './modal-opinion.component.html',
  styleUrl: './modal-opinion.component.css'
})
export class ModalOpinionComponent {
  //servicios a inyectar
  private _injector = inject(Injector);
  private _activatedRoute = inject(ActivatedRoute);

  //#region-----------------------
  private _idProd = signal<string>(this._activatedRoute.snapshot.paramMap.get('idProducto') as string);

  private _productoResource: Resource<IRestMessage> = resource(
    {
      request: this._idProd,
      loader: async ({ request, abortSignal, previous }) => {
        console.log('valor de parametros ResourceLoaderParams de la funcion loader...', request, abortSignal, previous);
        console.log('valor de la señal', this._idProd())//me pilla bien el id del producto pero en node me lo pone como undefined<-----arreglado
        let _resp = await fetch(
          `http://localhost:3003/api/zonaTienda/Producto?idProducto=${this._idProd()}`,
          { method: 'GET', signal: abortSignal }
        );
        let _body = await _resp.json();
        return _body ?? { codigo: 400, mensaje: '...error al recuperar producto....' }
      },
      injector: this._injector
    }
  );

  public producto = computed<IProducto | null>(() => {
    let _resp = this._productoResource.value();
    if (_resp?.codigo !== 0) return null;
    return _resp.datos;
  });


  //----------------metodos-------------------------
  @ViewChild('txtTitulo') txtTitulo!: ElementRef<HTMLInputElement>;
  @ViewChild('txtOpinion') txtOpinion!: ElementRef<HTMLTextAreaElement>;
  //id de en mongo, hay que hacerlo d eotra forma para hacerlo bien...
  private _idCliente = '67e1efd1fd6a52f623c9e52a';
  public estrellas = 0;
  public puntos = 0;


  public EstrellasSelect(i: number) {
    this.estrellas = i;

    console.log('estrellas', this.estrellas);
  }

  public PuntosSelect(i: number) {
    this.puntos = i;
  }

  //metodo para dehabilitar el boton si las estrellas o la puntuacion no esta marcada
  public botonEnviar(): boolean {
    return this.estrellas > 0 && this.puntos > 0
  }

  public async GuardarOpinion() {
    try {
      let _opinionNueva = {
        titulo: this.txtTitulo.nativeElement.value.trim(),
        opinion: this.txtOpinion.nativeElement.value.trim(),
        puntuacion: this.puntos,
        estrellas: this.estrellas,
        fechCreacion: Date.now(),
        tipo: 0,
        idCliente: this._idCliente,
        idProducto: this.producto()!._id
      };

      const resp = await fetch('http://localhost:3003/api/zonaTienda/GuardarOpinion',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(_opinionNueva)
        }
      );

      let _res = await resp.json();
      console.log('si el codigo es 0 la opinion se ha guardado bien...', _res.codigo)//<-- si me devuelve 0 supongo que ok
      

    } catch (error) {
      console.log('error al conectar con node para guardar opinion....', error);
    }
  }
  


  //#endregion------------------------------------

  private renderer2 = inject(Renderer2);
  punctuacionModal = Array.from({ length: 10 }, (el: any, pos: number) => pos + 1);

  //#region--------- metodos componente -------------
  Pinta(ev: Event, i: number) {
    console.log('sobre estrella...', ev.target, i);
    for (let index = 1; index <= 5; index++) {
      let _star = this.renderer2.selectRootElement(`i[id="estrella-${index}"]`, true);

      if (index <= i) {
        this.renderer2.setAttribute(_star, 'style', 'color: #0970e6;');
      } else {
        this.renderer2.setAttribute(_star, 'style', ' color:lightgray;');
      }
    }
  }

  Blanquea() {
    for (let index = 1; index <= 5; index++) {
      let _star = this.renderer2.selectRootElement(`i[id="estrella-${index}"]`, true);
      this.renderer2.setAttribute(_star, 'style', ' color:lightgray;');
    }
  }
  //#endregion
}
