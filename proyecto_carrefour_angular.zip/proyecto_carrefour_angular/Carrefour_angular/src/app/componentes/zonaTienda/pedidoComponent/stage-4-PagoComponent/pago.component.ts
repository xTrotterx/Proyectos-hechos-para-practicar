import { Component, inject, input, signal, WritableSignal } from '@angular/core';
import IPedido from '../../../../modelos/interfaces_orm/IPedido';
import { RestClientService } from '../../../../servicios/rest-client.service';
import IRestMessage from '../../../../modelos/IRestMessage';

@Component({
  selector: 'app-pago',
  imports: [],
  templateUrl: './pago.component.html',
  styleUrl: './pago.component.css'
})
export class PagoComponent {
  //---- inyeccion servicios -----
  private _restCliente=inject(RestClientService);

  //puedes inyectar el servicio StorageService para recuperar datos del pedido....
  //pero paso valor desde el comp.padre Pdido.component ---> Pago.component como señal input
  metodoPago=signal<string>('paypal');
  pedido=input<WritableSignal<IPedido>>()

//  respServer=signal<IRestMessage>({})
  

  ChangePayMode(metodo: string) {
      this.metodoPago.set(metodo);
  }

  FinalizarCompra() {
    let _datosPedido=(this.pedido()!)();
    switch(this.metodoPago()){
      case 'paypal':
        _datosPedido.metodoPago={ tipo: 'paypal'}
        break;

      case 'tarjeta':
        _datosPedido.metodoPago={ tipo: 'tarjeta', datosTarjeta:{ numeroTarjeta:'', cvv:'', fechaCaducidad:'', nombreTitular:''}}
        break;
    }

      let _resp=this._restCliente.FinalizarCompra(_datosPedido);
      if(_resp().codigo==0){
        //se ha creado bien la orden de pago del pedido ...se redirige al cliente a la plataforma de Paypal para q meta sus credenciales y acepte el pago (o no)
        //dos formas de trabajar:
        // - abres nueva ventana donde rediriges a paypal y cuando finalize el pago la cierras.... <=== mas segura...
        // - no abres ninguna ventana nueva, cambias url donde estabas a la url de paypal <--- para no perder datos de sesion los almacenas antes en el storage del navegador y luego los vuelves a 
        //   a recuperar
        console.log('respuesta desde node con url de pasarela de pago hacia paypal...', _resp());
        window.open(_resp().datos.urlPayPal, 'Pago con Paypal', 'popup');


      } else {
        //error al crear orden de pago a paypal...mostrar mensaje de q lo intente mas tarde...
        console.log( _resp().mensaje );
      }
  }

}
