import { Component, input, linkedSignal, output, signal } from '@angular/core';
import IProducto from '../../../../../modelos/interfaces_orm/IProducto';
import { DecimalPipe } from '@angular/common';
import { RedondearPipe } from '../../../../../pipes/redondear.pipe';

@Component({
  selector: 'app-mini-producto-cesta',
  imports: [ RedondearPipe ], //DecimalPipe,
  templateUrl: './mini-producto-cesta.component.html',
  styleUrl: './mini-producto-cesta.component.css'
})
export class MiniProductoCestaComponent {
  producto=input<IProducto>();
  cantidad=input.required<number>();

  // si lo dejamos asi no le da tiempo a la señal cantidadActual a cargar el valor del parametro de entrada desde la señal input: cantidad....
  // hacemos señal computada que derive de esta y asi evitamos el problema...como ademas esta señal la quieres modificar en botones +. - y borrar
  // debe ser una linkedSignal:
  
  //cantidadActual=signal<number>( this.cantidad()! ); <---- esto no vale, necesitas señal computada, q se refresque con cambio de valor de señal original cantidad

  cantidadActual=linkedSignal<number,number>(
    {
      source: this.cantidad,
      computation: ( source, previous)=>{
        return this.cantidad();
      }
    }
  )

  //si inyecto servicio storage para usar metodo setItemsPdido es ineficaz pq lo estas inyectando POR CADA ITEM DEL PEDIDO REPRESENTADO POR CADA MINICOMPONENTE...
  //mejor notiticamos con un eventEmitter o señal output al comp. padre q la cantidad ha cambiado o q directamente queremos borrar el item:
  operarEvent=output<{operacion:string, producto:IProducto, cantidad: number}>();


  ModificaCantidad(operacion: string) {
    switch (operacion) {
        case 'sumar':
        case 'restar':
          this.cantidadActual.set( operacion=='sumar' ? this.cantidadActual() + 1 : this.cantidadActual() - 1);
          this.operarEvent.emit( { operacion: 'modificarItem', producto: this.producto()!, cantidad: this.cantidadActual()} )

        break;

        case 'borrar':
          this.cantidadActual.set(0);
          this.operarEvent.emit( { operacion: 'borrarItem', producto: this.producto()!, cantidad: this.cantidadActual()} )
          break;
  
      default:
        break;
    }
    /*
        2 formas de actuar:

            disparo evento para q sea interceptado por comp.padre: micesta.component
            
              a- ese evento se progpaga, para que se lo comunique a su vez al comp. layout pedido.component y actualize subtotal,total
            (propagacion de evento). 
            
              b- Tb se puede hacer q en componente micesta.comp. se actualize la lista de items con metodo setItemsPedido ---> modifica objeto Pedido ---> si defines
            una señal en pedido.component q reciba los cambios de ese objeto pedido automaticamente se refresca

               ------ pedido.component -----------|
               |    header - nav bar stages       |
               |                          resumen |
               |  |-micesta.component -|  pedido  |
               |  |                    |          |
               |  |  mini-prod-ces.com |          |
               |  |  mini-prod-ces.com |          |
               |  |  mini-prod-ces.com |          |
               |  |  ....              |          |
               ------------------------------------    
    
    */      



  }
    

}
