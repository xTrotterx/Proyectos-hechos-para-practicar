import { Component, inject, OnInit, signal, viewChild, ViewContainerRef } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MicestaComponent } from './stage-1-MiCestaComponent/micesta.component';
import { DatosContactoComponent } from './stage-2-DatosContactoComponent/datos-contacto.component';
import { FechaEntregaComponent } from './stage-3-FechaEntregaComponent/fecha-entrega.component';
import { PagoComponent } from './stage-4-PagoComponent/pago.component';
import { NgStyle } from '@angular/common';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';
import IProducto from '../../../modelos/interfaces_orm/IProducto';
import IPedido from '../../../modelos/interfaces_orm/IPedido';

@Component({
  selector: 'app-pedido',
  imports: [RouterModule, NgStyle],
  templateUrl: './pedido.component.html',
  styleUrl: './pedido.component.css'
})
export class PedidoComponent implements OnInit {
//----- inyeccion de servicios ------
private _storage=inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);

public stages:Array<{ stage:number, nombre:string, component:any}>=[
    { stage: 1, nombre:'Mi Cesta', component: MicestaComponent},
    { stage: 2, nombre:'Datos de contacto', component: DatosContactoComponent},
    { stage: 3, nombre:'Entrega y Horario', component: FechaEntregaComponent },
    { stage: 4, nombre:'Pago', component: PagoComponent},

]
public stageActual=signal<number>(1)
public pedido=signal<IPedido>(this._storage.getPedido());

//hacemos referencia a variable template definida en la vista del componente para el contenedor ng-container donde se van a incrustar de forma dinamica
//los componentes que deseemos en funcion de eventos...en angular v.<10 se usaba directiva @ViewChild pues en ang.19 tienes señal viewchild
contenedor=viewChild('cont',{ read: ViewContainerRef } );


//#region ------------ metodos de clase componente -----------
ngOnInit(): void {
  this.SetStageActual(1);
  console.log('referencia al ng-content...', this.contenedor() )
}

SetStageActual(numberstage:number){
  //cargar en el ng-content el componente indicado por señal stageActual
  this.stageActual.set(numberstage);
  //console.log('ahora estas en teoria en el stage...', this.stages[this.stageActual() - 1 ]);

  this.contenedor()?.clear(); //<---- borramos previamente el contenedor por si tuviera ya algun componente previamente cargado de antes...
  const childCompRef=this.contenedor()?.createComponent(this.stages[this.stageActual() - 1 ].component );

  console.log('valor de referencia a componente dinamico incrustado en ng-container....', childCompRef);
  
  //en childCompRef esta un objeto de la clase de tipo ComponentRef, usandolo puedo saber que objeto se ha incrustado en el ng-container
  // childCompRef.componentType.name

  if(childCompRef?.componentType.name.includes("MicestaComponent")){
    //esta cargado dentro del ng-component el componente del stage-1, le paso como parametro input la variable mensaje
    childCompRef.setInput('mensaje','valor pasado dese PedidoComponent');
  
    //childCompRef.setInput('pedido', this._storage.getPedido() ); //<---- si lo dejo asi no refresca lista de items cada vez q modifico (sobre todo al borrar) en micesta.component
    childCompRef.setInput('pedido', this.pedido );
  
    //me susbscribo a eventemitter productido de forma señal-output en componente MicestaComponent
    (childCompRef.instance as MicestaComponent).itemModificado
                                               .subscribe( 
                                                      ( valor:{operacion:string, producto:IProducto, cantidad:number} ) => {
                                                            console.log('objeto RECIBIDO desde comp. mini-producto-cesta en comp.layout PEDIDO.COMPONENT....', valor);
                                                            //invocamos a metodo setItemsPedido del servicio....
                                                            this._storage.setItemsPedido(   valor.operacion, { producto: valor.producto, cantidad: valor.cantidad }  ); 
                                                            this.pedido.update( (ped:IPedido) => ({...ped, ...this._storage.getPedido() }))   
                                                       }
                                                );
  }

  if(childCompRef?.componentType.name.includes("PagoComponent")){
      childCompRef.setInput('pedido', this.pedido );
  }
}


//#endregion

}
