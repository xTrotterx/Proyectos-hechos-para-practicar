import { Component } from '@angular/core';

@Component({
  selector: 'app-datos-contacto',
  imports: [],
  templateUrl: './datos-contacto.component.html',
  styleUrl: './datos-contacto.component.css'
})
export class DatosContactoComponent {

}
