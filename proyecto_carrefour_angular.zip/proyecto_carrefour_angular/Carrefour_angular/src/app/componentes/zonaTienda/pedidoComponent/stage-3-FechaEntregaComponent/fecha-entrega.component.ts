import { Component } from '@angular/core';

@Component({
  selector: 'app-fecha-entrega',
  imports: [],
  templateUrl: './fecha-entrega.component.html',
  styleUrl: './fecha-entrega.component.css'
})
export class FechaEntregaComponent {

}
