import { Component, input, OnInit, output, WritableSignal } from '@angular/core';
import { MiniProductoCestaComponent } from './miniprodComp/mini-producto-cesta.component';
import IProducto from '../../../../modelos/interfaces_orm/IProducto';
import IPedido from '../../../../modelos/interfaces_orm/IPedido';

@Component({
  selector: 'app-micesta',
  imports: [ MiniProductoCestaComponent ],
  templateUrl: './micesta.component.html',
  styleUrl: './micesta.component.css'
})
export class MicestaComponent implements OnInit{

  mensaje=input<string>('');
  pedido=input<WritableSignal<IPedido>>();

  itemModificado=output<{ operacion: string; producto: IProducto; cantidad: number; }>()


  ngOnInit(): void {
    console.log('...parametro de entrada mensaje enviado desde comp.padre PedidoComponent:', this.mensaje());
    console.log('...parametro de entrada pedido  enviado desde comp.padre PedidoCompoonent:', this.pedido());
  }

  ModificaCantidadItem($event: { operacion: string; producto: IProducto; cantidad: number; }) {
      console.log('objeto recibido desde componente hijo mini-producto-cesta.component, lo propagamos hacia el comp.layout pedido.component..... ', $event);
      this.itemModificado.emit($event);
    }
}
