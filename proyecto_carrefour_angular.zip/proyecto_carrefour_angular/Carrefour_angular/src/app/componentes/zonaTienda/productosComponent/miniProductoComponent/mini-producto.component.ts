import { Component, inject, input, Input, signal } from '@angular/core';
import IProducto from '../../../../modelos/interfaces_orm/IProducto';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../../app.config';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mini-producto',
  imports: [],
  templateUrl: './mini-producto.component.html',
  styleUrl: './mini-producto.component.css'
})
export class MiniProductoComponent {
  //@Input() producto!:IProducto;
  producto=input.required<IProducto>();
  cantidadProd=signal<number>(0);

  //------ inyeccion servicios --------
  private _storage=inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);
  private _router=inject(Router);
  
  AddToCart():void {
    this.cantidadProd.set(1);
    this._storage.setItemsPedido('addItem',{ producto: this.producto(), cantidad: 1 })
  }

  SetCantidadProdFromInput(ev:any){
    ev.target.value !== '' ? this.cantidadProd.set( parseInt(ev.target.value) ) : this.cantidadProd.set(1)
  }

  ModificaCantidad(operacion:string){
    switch(operacion)
    {
      case 'suma':
        this.cantidadProd.set( this.cantidadProd() + 1);
        break;
      
      case 'resta': //<---- por aqui entra tanto si restas cantidad (señal cantidadActual > 1) o si quieres borrar (señal cantiadadActual == 1)
        this.cantidadProd.set( this.cantidadProd() - 1);
       break;
    }

    this._storage.setItemsPedido( this.cantidadProd()==0 ? 'borrarItem' : 'modificarItem', { producto: this.producto(), cantidad: this.cantidadProd() } )
  }

  IrAProducto(){
    this._router.navigate(['/Tienda/Producto', this.producto()._id])
  }
}
