import { Component, computed, inject, Injector, resource, Resource, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import IRestMessage from '../../../modelos/IRestMessage';
import IProducto from '../../../modelos/interfaces_orm/IProducto';
import { MiniProductoComponent } from './miniProductoComponent/mini-producto.component';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../../../app.config';

@Component({
  selector: 'app-productos',
  imports: [MiniProductoComponent],
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.css'
})
export class ProductosComponent {
  // -------- injeccion servicios ------------
  private _activatedRoute=inject(ActivatedRoute);
  private _injector=inject(Injector);

  
  //recuperamos productos de categoria pasada en segmetno url :pathCat mediante funcion resource 
  //(se podria hacer tambien usando servicio como toda la vida...)
  private _pathCat=signal<string>(this._activatedRoute.snapshot.paramMap.get('pathCat') as string);

  private _productosResouce: Resource<IRestMessage>=resource(
    {
      request: this._pathCat,
      loader: async ( {request, abortSignal, previous } )=>{
        console.log('valor de parametros ResourceLoaderParams de la funcion loader...', request, abortSignal, previous);
        let _resp=await fetch(
                              `http://localhost:3003/api/zonaTienda/Productos?pathCat=${this._pathCat()}`,
                               { method: 'GET', signal: abortSignal }
                              );
        let _body=await _resp.json();
        return _body ?? { codigo:400, mensaje:'...recuperando productos....'} 
      },
      injector: this._injector
    }
  );

  public productos=computed<IProducto[]>( ()=> this._productosResouce.value() ?  (this._productosResouce.value().codigo==0 ? this._productosResouce.value().datos : [] ): [] );



}
