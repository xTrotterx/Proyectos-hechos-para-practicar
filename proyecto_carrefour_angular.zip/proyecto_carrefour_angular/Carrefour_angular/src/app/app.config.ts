import { ApplicationConfig, InjectionToken, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { StorageGlobalService } from './servicios/storage-global.service';
import { LocalStorageGlobalService } from './servicios/local-storage-global.service';

import IStorageService from './modelos/IStorageServices'
import { authInterceptor } from './interceptors/auth.interceptor';

//tengo q definir inyeccion del servicio storage-global.service cuando componentes,...de la aplicacion
//me soliciten objeto que implemente interfaces IStorageService, como no se puede poner en propiedad "provide"
//una interface (pq no puede construirse un objeto a partir de ella), se necesita de un InjectionTojen asociado a la misma

export const HTTP_INJECTIONTOKEN_STORAGE_SVCS:InjectionToken<IStorageService>=new InjectionToken<IStorageService>('token asociado a servicios q implementan interface IStorageService');

//para devolver array de todos los servicios que implementen interface...
//export const HTTP_INJECTIONTOKEN_STORAGE_SVCS:InjectionToken<IStorageService[]>=new InjectionToken<IStorageService[]>('token asociado a servicios q implementan interface IStorageService');

export const appConfig: ApplicationConfig = {
  providers: [
                //{ provide: LocalStorageGlobalService, useClass: LocalStorageGlobalService }, 
                //{ provide: StorageGlobalService, useValue: { datos:'esto es una constante' }},//useExisting: LocalStorageGlobalService },
                
                //....definicion de proveedor para devolver array de todos los servicios que implementen interface...
                //{ provide: HTTP_INJECTIONTOKEN_STORAGE_SVCS, useClass: StorageGlobalService, multi: true },
                //{ provide: HTTP_INJECTIONTOKEN_STORAGE_SVCS, useClass: LocalStorageGlobalService, multi: true },

                //...solo un servicio Storage:
                { provide: HTTP_INJECTIONTOKEN_STORAGE_SVCS, useClass: StorageGlobalService },
                provideZoneChangeDetection({ eventCoalescing: true }),
                provideRouter(routes), //<--------- el modulo de DI de angular puede inyectar el servicio de enrutamiento Router para q los componentes puedan invocarlo desde codigo
                provideHttpClient( withInterceptors([ authInterceptor ]) ),  // <--------- el modulo de DI de angular puede inyectar el servicio HttpClient para hacer pet.ajax al exterior
              ]
};
