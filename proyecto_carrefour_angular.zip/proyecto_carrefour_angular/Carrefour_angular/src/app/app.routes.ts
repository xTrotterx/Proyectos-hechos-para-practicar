import { Routes } from '@angular/router';
import { RegistroComponent } from './componentes/zonaCliente/registroComponent/registro.component';
import { LoginComponent } from './componentes/zonaCliente/loginComponent/login.component';
import { LayoutComponent } from './componentes/zonaTienda/layOutComponent/layout.component';
import { HomeComponent } from './componentes/zonaTienda/homeComponent/home.component';
import { Verif2FACodeComponent } from './componentes/zonaCliente/verificacion2FAComponent/verif2-facode.component';
import { ProductosComponent } from './componentes/zonaTienda/productosComponent/productos.component';
import { PedidoComponent } from './componentes/zonaTienda/pedidoComponent/pedido.component';
import { MicestaComponent } from './componentes/zonaTienda/pedidoComponent/stage-1-MiCestaComponent/micesta.component';
import { FechaEntregaComponent } from './componentes/zonaTienda/pedidoComponent/stage-3-FechaEntregaComponent/fecha-entrega.component';
import { DatosContactoComponent } from './componentes/zonaTienda/pedidoComponent/stage-2-DatosContactoComponent/datos-contacto.component';
import { PagoComponent } from './componentes/zonaTienda/pedidoComponent/stage-4-PagoComponent/pago.component';
import { MostrarProductoComponent } from './componentes/zonaTienda/mostrarProdComponent/mostrar-producto.component';
import { InicioPanelComponent } from './componentes/zonaCliente/PANEL/inicio-panel.component';

//array de objetos Route que mapea url del navegador con componente a cargar
//cada vez q hay un cambio en la url, el servicio Router de angular se dispara, intercepta esa url
//chequea este array de objetos hasta q encuentra el 1º cuyo prop. "path" coincida, y carga componente

export const routes: Routes = [
    { path:'', redirectTo: '/Tienda/Home', pathMatch: 'full'},
    {
     path: 'Tienda',
     component: LayoutComponent,
     children:[
      { path:'Home', component: HomeComponent },
      { path:'Productos/:pathCat', component: ProductosComponent },
      { path: 'Producto/:idProducto', component: MostrarProductoComponent }
     ]
    },
    { path:'Pedido', component: PedidoComponent },
    //----- estableciendo PedidoComponent como un layout para los componentes de los diferentes stages...
    // {
    //   path: 'Pedido',
    //   component: PedidoComponent,
    //   children: [
    //     { path:'MiCesta', component: MicestaComponent },
    //     { path:'FechaEntrega', component: FechaEntregaComponent},
    //     { path: 'DatosContacto', component: DatosContactoComponent },
    //     { path: 'Pago', component: PagoComponent}
    //   ]
    // },
    { 
      path :'Cliente',
      children:[
        { path:'Registro', component: RegistroComponent },
        { path:'Login', component: LoginComponent },
        { path:'Verificar/:operacion', component: Verif2FACodeComponent },
        { path: 'Panel', 
          children:[
            {path: 'Inicio', component: InicioPanelComponent }
          ]
      }
        
      ]
    }
]; 