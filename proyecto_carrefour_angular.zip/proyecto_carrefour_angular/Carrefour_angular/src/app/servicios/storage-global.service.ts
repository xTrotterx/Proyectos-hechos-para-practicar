import { Injectable, signal } from '@angular/core';
import IStorageService from '../modelos/IStorageServices';
import ICliente from '../modelos/interfaces_orm/ICliente';
import IJwtFormat from '../modelos/IJwtFormat';
import IPedido from '../modelos/interfaces_orm/IPedido';
import IProducto from '../modelos/interfaces_orm/IProducto';

@Injectable({
  providedIn: 'root'
})
export class StorageGlobalService implements IStorageService {

  private _jwt=signal<IJwtFormat>( {sesion: '', verificacion:'', refresh:'' } )
  private _codigo=signal<string>('');
  private _datosCliente=signal<ICliente | undefined>( undefined )

  private _pedidoActual=signal<IPedido>(
    {
    itemsPedido:[],
    metodoPago: {},
    fechaPago: Date.now(),
    fechaEnvio: Date.now(),
    estado: '',
    subtotal: 0,
    gastosEnvio: 0,
    total: 0      
    }
  );  
  constructor() { }
  
  //#region --------------------------- metodos para gestionar datos entre componentes zonaCliente --------
  getJWT():IJwtFormat{
    return this._jwt()
  }
  
  getCodigoVerificacion(): string{
    return this._codigo();
  }

  getDatosCliente(): ICliente | undefined{
    return this._datosCliente();
  }

  setJwt(tipo: string, value: string){
    //meto en objeto de señal en propiedad "tipo" (sesion, verificacion, refresh) el valor: "value"
    // { refresh: ...., sesion: ..., verificacion: .... }
    this._jwt.update(valorprev => ({  ...valorprev, [tipo]: value } ) )
  }
  
  setCodigoVerificacion(codigo: string){
      this._codigo.set(codigo);
  }

  setDatosCliente(datosCliente: ICliente){
    this._datosCliente.update(
                                valorprev => {
                                  if(!! valorprev){
                                      return { ...valorprev, ...datosCliente };
                                  } else {
                                    return {...datosCliente};
                                  }
        }
    )
  }
  //#endregion

  //#region --------------------------- metodos para  gestionar datos entre componentes zonaTienda ----------
  
  getPedido():IPedido {
    return this._pedidoActual();
  }

  setItemsPedido( operacion:string, item:{ producto: IProducto, cantidad: number }) {
    let _items:Array<{ producto:IProducto, cantidad:number}>=this._pedidoActual().itemsPedido;
    let _pos:number=_items.findIndex( it => it.producto._id == item.producto._id);

    switch (operacion) {
      case 'addItem':
            //antes de añadir el item al array, debo comprobar si existe o no...pq sino duplica el mismo item con cantidad=1
            if(_pos == -1){
              console.log('en addItem, no existe el producto en array de items pedido y lo añadimos...')
              _items.push(item);
          } else {
              console.log('en addItem, el producto a añadir al pedido ya existe en items pedido, INCREMENTAMOS CANTIDDAD EN UNO');
              _items=_items.map( it => it.producto._id !== item.producto._id ? it : { ...it, cantidad: it.cantidad + 1})
          }              
          break;        
    
      case 'borrarItem':
          console.log('en borrarItem....');
          _items=_items.filter( it => it.producto._id !== item.producto._id);
          break;

      case 'modificarItem':
          console.log('modificando item, se da por hecho que ya existe el producto en itemsPedido, la variable _pos vale....', _pos);
          if ( _pos !== -1){
              _items=_items.map( it => it.producto._id !== item.producto._id ? it : { ...it, cantidad: item.cantidad})
          }
          break;

      default:
        break;
    }
    let _subtotal=Math.round( _items.reduce( (ac, el)=> (el.producto.precio * el.cantidad) + ac, 0  ) * 100) / 100;
    let _total=Math.round( (_subtotal + this._pedidoActual().gastosEnvio) * 100) / 100;

    this._pedidoActual.update(
                              (pedidoAct:IPedido)=> (
                                {
                                  ...pedidoAct,
                                  itemsPedido: _items,
                                  subtotal: _subtotal,
                                  total: _total
                                }
                              )
                    )

      console.log('como esta el pedido actual despues de invocar metodo SetItemsPedido...', this._pedidoActual());

  }

  //#endregion

}
