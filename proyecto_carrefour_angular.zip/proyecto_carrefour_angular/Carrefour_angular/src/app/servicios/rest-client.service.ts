import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, Injector, Signal } from '@angular/core';
import IRestMessage from '../modelos/IRestMessage';
import { debounceTime, defaultIfEmpty, Observable, startWith, tap } from 'rxjs';
import { toSignal } from '@angular/core/rxjs-interop';
import IPedido from '../modelos/interfaces_orm/IPedido';
import { HTTP_INJECTIONTOKEN_STORAGE_SVCS } from '../app.config';
import IOpinon from '../modelos/interfaces_orm/IOpinion';

@Injectable({
  providedIn: 'root'
})
export class RestClientService {

  private _httpClient = inject(HttpClient);
  private _injector = inject(Injector);
  private _storage = inject(HTTP_INJECTIONTOKEN_STORAGE_SVCS);

  constructor() { }

  //#region ------------------ metodos pet.a servicio nodejs de zonaCliente ---------------
  public LoginRegistroCliente(datos: any, operacion: string): Signal<IRestMessage> {
    return toSignal(
      this._httpClient
        .post<IRestMessage>(
          `http://localhost:3003/api/zonaCliente/${operacion}`,
          datos,
          { headers: new HttpHeaders({ 'Content-Type': 'application/json ' }) }
        )
        .pipe(
          startWith({ codigo: 100, mensaje: '...esperando respuesta del server.... ' }), //<------ inicializo el observable a un valor hasta q el servicio nodejs me conteste
        )
      , { injector: this._injector, requireSync: true }
    );

  }

  public VerificarCodigo(operacion: string, codigo: string, jwt: string, email: string): Signal<IRestMessage> {
    return toSignal(
      this._httpClient
        .post<IRestMessage>(
          'http://localhost:3003/api/zonaCliente/VerificarCodigo',
          { operacion, codigo, jwt, email },
          { headers: new HttpHeaders({ 'Content-Type': 'application/json ' }) }
        )
        .pipe(
          startWith({ codigo: 100, mensaje: '...esperando respuesta del server.... ' }), //<------ inicializo el observable a un valor hasta q el servicio nodejs me conteste
        )
      , { injector: this._injector, requireSync: true }
    );
  }

  public RefrescarTokens(refreshToken: string): Observable<IRestMessage> {
    return this._httpClient
      .post<IRestMessage>(
        'http://localhost:3003/api/zonaCliente/RefrescarTokens',
        { refreshToken },
        { headers: new HttpHeaders({ 'Content-Type': 'application/json ' }) }
      )
      .pipe(
        tap(
          (resp: IRestMessage) => {
            //si la respuesta del servicio de nodejs tiene codigo 0, en datos van el accesstoken y el refresh nuevos actualizados...los almaceno
            //en servicio
            this._storage.setJwt('sesion', resp.datos.sesionjwt);
            this._storage.setJwt('refresh', resp.datos.refreshjwt);
          }
        )
      )
  }



  //#endregion

  //#region ------------------ metodos pet.a servicio nodejs de zonaTienda ---------------
  public FinalizarCompra(pedido: IPedido): Signal<IRestMessage> {
    return toSignal(
      this._httpClient
        .post<IRestMessage>(
          'http://localhost:3003/api/zonaTienda/FinalizarCompra',
          { ...pedido },
          { headers: new HttpHeaders({ 'Content-Type': 'application/json ' }) }
        )
        .pipe(
          startWith({ codigo: 100, mensaje: '...esperando respuesta del server.... ' }), //<------ inicializo el observable a un valor hasta q el servicio nodejs me conteste
        )
      , { injector: this._injector, requireSync: true }
    );

  }
  
  //#endregion



}
