import { Injectable } from '@angular/core';
import IStorageService from '../modelos/IStorageServices';
import IJwtFormat from '../modelos/IJwtFormat';
import ICliente from '../modelos/interfaces_orm/ICliente';
import IPedido from '../modelos/interfaces_orm/IPedido';
import IProducto from '../modelos/interfaces_orm/IProducto';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageGlobalService implements IStorageService {

  constructor() { }
  getPedido():IPedido {
    throw new Error('sin implementar....para el becario');
  }

  setItemsPedido(operacion: string, item: { producto: IProducto; cantidad: number; }) {
    throw new Error('sin implementar....para el becario');
  }


  
  getJWT():IJwtFormat {
    return JSON.parse(localStorage.getItem('jwt')!) as IJwtFormat ?? undefined;
  }
  
  getCodigoVerificacion(): string{
    return localStorage.getItem('codigo') ?? '';
  }

  getDatosCliente(): ICliente | undefined{
    return JSON.parse(localStorage.getItem('datosCliente')!) as ICliente ?? undefined
  }

  setJwt(tipo: string, value: string){
    //meto en objeto de señal en propiedad "tipo" (sesion, verificacion, refresh) el valor: "value"
    // { refresh: ...., sesion: ..., verificacion: .... }
     
    if(!! localStorage.getItem('jwt')){
       var _jwtEnStorage:IJwtFormat = JSON.parse(localStorage.getItem('jwt')!);      
     } else {
       var _jwtEnStorage:IJwtFormat={sesion:'', refresh:'', verificacion:''};
    }

      _jwtEnStorage={ ..._jwtEnStorage, [tipo]: value }; 
      localStorage.setItem('jwt', JSON.stringify(_jwtEnStorage))
      

  }
  
  setCodigoVerificacion(codigo: string){
     localStorage.setItem('codigo', codigo);
  }

  setDatosCliente(datosCliente: ICliente){
    
  }
}
