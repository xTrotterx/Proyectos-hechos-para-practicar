export default interface IJwtFormat {
    sesion: string,
    refresh: string,
    verificacion:string
}