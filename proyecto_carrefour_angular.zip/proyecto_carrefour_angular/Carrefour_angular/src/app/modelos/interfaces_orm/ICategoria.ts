export default interface ICategoria {
    imagen: string,
    nombreCategoria: string,
    pathCategoria: string
}