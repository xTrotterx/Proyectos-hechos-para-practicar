export default interface IOpinion{
    titulo:string,
    opinion?:string,
    puntuacion:number,
    estrellas:number,
    fechCreacion:number,
    //esto es si le gusta o no
    tipo:number,
    idCliente:string,
    idProducto:string,
}

