import IDireccion from "./IDireccion";
import IOpinon from "./IOpinion";

export default interface ICliente {
    nombre: string,
    apellidos: string,
    telefono: string,
    cp?: string,
    tarjetaCarrefour?: string,
    cuenta: { email:string, password?: string},
    activada: Boolean,
    documento: { tipo: string, valor: string },
    direcciones: [ IDireccion ],
    pedidos:[ ],
    opiniones:[IOpinon]

}