import IDireccion from "./IDireccion";
import IProducto from "./IProducto";

export default interface IPedido {
    itemsPedido: Array<{ producto: IProducto, cantidad: number}>,
    metodoPago: any,
    direccionEnvio?: IDireccion,
    direccionFacturacion?: IDireccion,
    fechaPago: number,
    fechaEnvio: number,
    estado: string,
    subtotal: number,
    gastosEnvio: number,
    total: number
}