import IJwtFormat from "./IJwtFormat";
import ICliente from "./interfaces_orm/ICliente";
import IPedido from "./interfaces_orm/IPedido";
import IProducto from "./interfaces_orm/IProducto";

export default interface IStorageService {
    getJWT: ()=> IJwtFormat ,
    getCodigoVerificacion: ()=> string,
    getDatosCliente: ()=> ICliente | undefined,
    setJwt: (tipo:string, valor:string ) => void,
    setCodigoVerificacion: (codigo:string) => void,
    setDatosCliente: (datosCliente: ICliente) => void

    getPedido: ()=>IPedido,
    setItemsPedido: ( operacion:string, item:{ producto: IProducto, cantidad: number } )=>void
}