import axios from 'axios';



export default {
    GetAccessToken: async function(): Promise<string> {
        //https://developer.paypal.com/api/rest/authentication/
        try {
            const _base64Auth=Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64');
            let _petToken=await axios(
                {
                    method:'POST',
                    url: "https://api-m.sandbox.paypal.com/v1/oauth2/token",
                    data: 'grant_type=client_credentials',
                    headers: {
                        'Content-Type':'application/x-www-form-urlencoded',
                        'Authorization': `Basic ${_base64Auth}`
                    }
                }
            );
            if( _petToken.status==200){
                /*
                    si todo ok, en el body te manda objeto de este formato:
                    {
                    "scope": "https://uri.paypal.com/services/invoicing https://uri.paypal.com/services/disputes/read-buyer https://uri.paypal.com/services/payments/realtimepayment https://uri.paypal.com/services/disputes/update-seller https://uri.paypal.com/services/payments/payment/authcapture openid https://uri.paypal.com/services/disputes/read-seller https://uri.paypal.com/services/payments/refund https://api-m.paypal.com/v1/vault/credit-card https://api-m.paypal.com/v1/payments/.* https://uri.paypal.com/payments/payouts https://api-m.paypal.com/v1/vault/credit-card/.* https://uri.paypal.com/services/subscriptions https://uri.paypal.com/services/applications/webhooks",
                    "access_token": "A21AAFEpH4PsADK7qSS7pSRsgzfENtu-Q1ysgEDVDESseMHBYXVJYE8ovjj68elIDy8nF26AwPhfXTIeWAZHSLIsQkSYz9ifg",
                    "token_type": "Bearer",
                    "app_id": "APP-80W284485P519543T",
                    "expires_in": 31668,
                    "nonce": "2020-04-03T15:35:36ZaYZlGvEkV4yVSz8g6bAKFoGSEzuy3CQcz3ljhibkOHg"
                    }                    
                */
               console.log('respuesta al servicio rest de paypal solictiando token de acceso...', _petToken.data);
               return (_petToken.data as any).access_token as string;

            } else {
                throw new Error('error al intentar crear token de acceso a la API de PAYPAL...');
            }
            

        } catch (error) {
            console.log('error al intentar obtener token acceso operaciones contra paypal...', error);
            return ''
        }
    },
    CreateOrder: async function(idCliente: string, pedido: any ): Promise<any>{
        try {
                //como crear orden de pago en Paypal: https://developer.paypal.com/docs/api/orders/v2/
                let _accessToken=await this.GetAccessToken();
                let _order={
                    intent: 'CAPTURE',
                    purchase_units: [
                        {
                            items: pedido.itemsPedido.map( (itemPedido:any)=> {
                                return {
                                    name: itemPedido.producto.nombre,
                                    quantity: itemPedido.cantidad.toString(),
                                    unit_amount: { currency_code: 'EUR', value: itemPedido.producto.precio.toString()}

                                }
                            }),
                            amount: {
                                currency_code: 'EUR',
                                value: pedido.total.toString(),
                                breakdown: {
                                    shipping: { currency_code: 'EUR', value: pedido.gastosEnvio.toString() },
                                    item_total: {currency_code: 'EUR', value: pedido.subtotal.toString() }
                                }
                            }
                        }
                    ],
                    //para la generacion de las urls de aceptacion pago/cancelacion uso propiedad application_context.. la api dice que esta DEPRECATED
                    //y hay q usar: payment_source ---> paypal ---> experience_context ---> user_action 
                    //demasiada complicacion de momento, usamos application_context mientras nos lo permita PAYPAL
                    application_context:{
                        return_url:`http://localhost:3003/api/zonaTienda/PayPalCallback?idCliente=${idCliente}&idPedido=${pedido._id}`,
                        cancel_url:`http://localhost:3003/api/zonaTienda/PayPalCallback?idCliente=${idCliente}&idPedido=${pedido._id}&Cancel=true`
                    }
                }

                let _petOrder=await axios(
                    {
                        method:'POST',
                        url:'https://api-m.sandbox.paypal.com/v2/checkout/orders',
                        headers:{
                            'Authorization': `Bearer ${_accessToken}`,
                            'Content-Type': 'application/json'
                        },
                        data: JSON.stringify(_order)
                    }
                );
                if( _petOrder.status==201){
                    //peticion de creacion orde de pago del pedido creada correctamente...
                    console.log('respuesta de paypal ante la creacion del objeto ORDER de pedido...', _petOrder.data);
                    
                    const _linkRedirect=(_petOrder.data as any).links.filter( ((link:any)=> link.rel=='approve' )).map( (link:any) => link.href)[0] || '';
                    if (_linkRedirect == '') throw new Error('error al generar link de redireccion hacia la pasarela de pago de PAYPAL al cliente...');

                    return { 
                                link: _linkRedirect, 
                                idPedidoPayPal: (_petOrder.data as any).id
                            };
                } else {
                    throw new Error('error al intentar pasar a PAYPAL la orden de creacion de cobro del pedido...');
                }
            
        } catch (error) {
            console.log('error al intentar crear objeto pedido o Orden en paypal...', error);
            return null;
        }

    },
    CobrarPedidoPayPayl: async function(idPedidoPayPal:string ):Promise<any>{
        try {
            //1º antes de solicitar el cobro, necesio token de acceso a la api:
            let _accessToken=await this.GetAccessToken();

            //capture del objeto ORDER con ese id: https://developer.paypal.com/docs/api/orders/v2/#orders_capture
            let _petConfirm=await axios(
                {
                    method:'POST',
                    url: `https://api-m.sandbox.paypal.com/v2/checkout/orders/${idPedidoPayPal}/capture`,
                    headers: {
                        'Content-Type':'application/json',
                        'Authorization': `Bearer ${_accessToken}`,
                        //'Prefer': 'return=representation'
                    },
                }
            )
            if(_petConfirm.status==201) //<---- el .status es 201 pq da como respuesta objeto formato corto...si poners cabecera en peticion Prefer:  return=representation
                                        //      el codigo de salida es 200 y la respuesta se da en formato largo
            {
                console.log('respuesta dada por paypal al pedirle el cobro del pedido...', _petConfirm.data);
                return _petConfirm.data;
            } else {
                throw new Error("error al procesar pago en paypal");
                
            }

        } catch (error) {
            console.log('error al realizar cobro del dinero del pedido en paypal....', error);
            return null;
        }
    }
}