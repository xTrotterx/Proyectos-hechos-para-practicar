import axios from 'axios';

export default {
    EnviarEmail: async ( nombre:string, apellidos:string, to:string, subject:string, body:string, htmlbody:string )=>{
        try {
            const _credsBASE64=Buffer.from(`${process.env.MAILJET_PUBLIC_APIKEY}:${process.env.MAILJET_SECRET_APIKEY}`,'utf-8').toString('base64');
            const _mensaje={
                "Messages": [
                    {
                        "From": { "Email": "pmr.aiki@gmail.com", "Name":"administrador de Carrefour "},
                        "To": [
                            {
                                "Email": to,
                                "Name": apellidos +", " + nombre
                            }
                        ],
                        "Subject": subject,
                        "TextPart": body,
                        "HTMLPart": htmlbody
                    }
                ]
            };
            /*
                 envio email: https://dev.mailjet.com/email/guides/send-api-v31/ ...
                formato respuesta: 
                    {
                    "Messages": [
                        {
                        "Status": "success",
                        "To": [
                            {
                            "Email": "passenger1@mailjet.com",
                            "MessageUUID": "123",
                            "MessageID": 456,
                            "MessageHref": "https://api.mailjet.com/v3/message/456"
                            }
                        ]
                        }
                    ]
                    }                
            */
            let _respEnvio=await axios(
                { 
                    method:'POST',
                    url:'https://api.mailjet.com/v3.1/send',
                    headers: {
                        'Content-Type':'application/json',
                        'Authorization': `Basic ${_credsBASE64}`
                    },
                    data: JSON.stringify(_mensaje)

                }
            );
            console.log('respuesta envio email al cliente...', _respEnvio.data);
            if ((_respEnvio.data as any).Messages[0].Status !=='success') throw new Error('error en envio de mail al usuario: ' + _respEnvio.data);
            return true;

        } catch (error) {
            console.log('error envio email', error);
            return false;

        }
    }
}