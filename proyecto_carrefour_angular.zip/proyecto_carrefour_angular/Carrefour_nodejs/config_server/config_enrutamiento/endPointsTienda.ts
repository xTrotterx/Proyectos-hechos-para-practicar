import express from 'express';
import tiendaEndPointController from './endpointsControllers/tiendaEndPointController';

//funciones middleware para endpoints zonaCliente definidos con objeto Router de express
const routerTienda=express.Router();

routerTienda.get('/Categorias', tiendaEndPointController.Categorias );
routerTienda.get('/Productos', tiendaEndPointController.Productos );
routerTienda.post('/FinalizarCompra', tiendaEndPointController.FinalizarCompra );

//---- enpoint invocado por servidor de PAYPAL cuando el cliente acepta el pago dentro de la pasarela, no por el cliente de angular...-----
routerTienda.get('/PayPalCallback', tiendaEndPointController.PayPalCallback );

//endpoints del examen
routerTienda.get('/Producto',tiendaEndPointController.RecuperarProducto);
routerTienda.post('/GuardarOpinion', tiendaEndPointController.GuardarOpinion);
routerTienda.get('/RecuperarOpiniones', tiendaEndPointController.RecuperarOpiniones);

export default routerTienda;