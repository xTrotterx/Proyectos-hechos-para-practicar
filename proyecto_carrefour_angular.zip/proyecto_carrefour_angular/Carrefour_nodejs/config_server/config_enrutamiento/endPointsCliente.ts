import express from 'express';
import clienteEndPointController from './endpointsControllers/clienteEndPointController';
import { verificarJWT } from '../../utilidades/middlewares-globales/verificarJWT';

//funciones middleware para endpoints zonaCliente definidos con objeto Router de express
const routerCliente=express.Router();

routerCliente.post('/Registro', clienteEndPointController.Registro );
routerCliente.post('/Login', clienteEndPointController.Login );
routerCliente.post('/VerificarCodigo', verificarJWT, clienteEndPointController.VerificarCodigo );
routerCliente.post('/RefrescarTokens', clienteEndPointController.RefrescarTokens);


export default routerCliente;