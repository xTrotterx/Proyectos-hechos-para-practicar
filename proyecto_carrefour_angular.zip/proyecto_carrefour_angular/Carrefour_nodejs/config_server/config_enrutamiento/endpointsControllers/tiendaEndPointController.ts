import { Request, Response, NextFunction } from "express";
import mongoose from "mongoose";
import Categoria from "../../../modelos/modelos_mongoose_orm/categoria";
import Producto from "../../../modelos/modelos_mongoose_orm/producto";
import Pedido from "../../../modelos/modelos_mongoose_orm/pedido";
import paypal from "../../../servicios/paypal";
import Opinion from "../../../modelos/modelos_mongoose_orm/opinion"
import Cliente from "../../../modelos/modelos_mongoose_orm/cliente";
import { send } from "process";

export default {
    Categorias: async (req: Request, res: Response, next: NextFunction) => {
        try {
            let pathCat = req.query.pathCat;
            console.log('pathCat en url desde angular...', pathCat);

            let _pattern: string = '^\\d+$'; //<--- por defecto cats.raices
            if (pathCat !== 'raices') _pattern = `${pathCat}-(\\d+-?)`;

            let _regex: RegExp = new RegExp(_pattern);
            await mongoose.connect(process.env.MONGODB_URL!);

            let _cats = await Categoria.find({ pathCategoria: { $regex: _regex } });
            console.log('categorias recuperadas....', _cats.length);

            res.status(200).send({ codigo: 0, mensaje: 'categorias recuperadas ok...', datos: _cats });

        } catch (error) {
            console.log('error al recuperar categorias....', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al recuperar categorias: ' + error });
        }
    },
    Productos: async (req: Request, res: Response, next: NextFunction) => {
        try {
            let pathCat = req.query.pathCat;
            console.log('pathCat en url desde angular...', pathCat);

            await mongoose.connect(process.env.MONGODB_URL!);

            let _prods = await Producto.find({ pathCategoria: pathCat });
            console.log('productos recuperados....', _prods);

            res.status(200).send({ codigo: 0, mensaje: 'productos recuperados ok...', datos: _prods });

        } catch (error) {
            console.log('error al recuperar productos....', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al recuperar productos: ' + error });
        }
    },
    FinalizarCompra: async (req: Request, res: Response, next: NextFunction) => {
        try {

            const _pedido = new Pedido(req.body);
            console.log('pedido enviado desde servicio de angular y el creado con esquema mongoose...', req.body, _pedido);
            console.log('en propiedad req.jwtPayload estan los claims del jwt-sesion...', (req as any).jwtPayload);

            const { idCliente, ...resto } = (req as any).jwtPayload;

            let datos = {};

            switch (_pedido.metodoPago?.tipo) {
                case 'paypal':
                    let _respOrder = await paypal.CreateOrder(idCliente, _pedido);
                    if (!_respOrder) throw new Error('Error al crear orden de pago en paypal para el pedido...');


                    const { link, idPedidoPayPal } = _respOrder;
                    //....almaceno en mongodb en coleccion paypalorders documento con: { idCliente: ...., idPedidoPayPal: ...., idPedido: ..._id mongoose...  }
                    await mongoose.connect(process.env.MONGODB_URL!);
                    const _resInsert: mongoose.mongo.InsertOneResult = await mongoose.connection.collection('paypalorders').insertOne({ idCliente, idPedidoPayPal, idPedido: _pedido._id.toString() });

                    console.log('resultado insert en coleccion paypalorders...', _resInsert);
                    if (!_resInsert.insertedId) throw new Error('error al insertar en mongo datos del pedido paypal...pero paypal lo ha creado ok, putadon, mierda de  mongo...');

                    datos = { urlPayPal: link };

                    break;






                case 'tarjeta':

                    break;


                default:
                    break;
            }
            res.status(200).send({ codigo: 0, mensaje: 'pago realizado ok', datos })


        } catch (error) {
            console.log('error al finalizar pago del pedido...', error);
            res.status(200).send()
        }
    },
    PayPalCallback: async (req: Request, res: Response, next: NextFunction) => {
        //desde el servidor de paypal se mandan por GET estos parametros: idCliente, idPedido y opcional Cancel...
        //!!! OJO, ESTE METODO SE DISPARA POR EL SERVIDOR DE PAYPAL !!!!            
        console.log('paramwtros en req.query pasados por servidor paypal...', req.query);
        const { idCliente, idPedido, Cancel } = req.query

        try {
            if (Cancel) throw new Error('Pedido cancelado por usuario en el ultimo momento desde paypal....');

            //paypal me dice q usuario ha aceptado el cobro, lo pasamos/cobramos a la pasarela...recupero de mongo el idPedidoPaypal
            await mongoose.connect(process.env.MONGODB_URL!);
            let _paypalorder = await mongoose.connection.collection('paypalorders').findOne({ idCliente, idPedido });
            if (!_paypalorder) throw new Error(`no hay ningun pedido de paypal para ese idCliente: ${idCliente} y idPedido${idPedido}`);

            let _idPedidoPayPal = _paypalorder.idPedidoPayPal;
            let _finPago = await paypal.CobrarPedidoPayPayl(_idPedidoPayPal);

            if (!_finPago) throw new Error('error cobro del pedido en paypal...putadon');

            // res.status(200).send(...) <--- no puedo hacer un .send() pq mandaria respuesta con esos datos al servidor de paypal...y a paypal ni le interesa
            //tengo q redireccionar la peticion hacia el servidor web donde esta desplegado mi aplicacion angular, al componente q me interese...
            res.status(200).redirect(`http://localhost:4200/PedidoResult?idCliente=${idCliente}&idPedido=${idPedido}&idPedidoPayPal=${_idPedidoPayPal}&opCode=0`);


        } catch (error) {
            console.log('error al finalizar pago del pedido...', error);
            // res.status(200).send(...) <--- no puedo hacer un .send() pq mandaria respuesta con esos datos al servidor de paypal...y a paypal ni le interesa
            //tengo q redireccionar la peticion hacia el servidor web donde esta desplegado mi aplicacion angular, al componente q me interese...

            //OJO!!! pq perderias todo el estado de sesion al ser invocacion nueva...pero cargas una pagina nueva estatica donde no haga falta estado de sesion
            //ESTE COMPONENTE SE MOSTRARIA EN EL POPUP donde has abierto la pasarela de pago SI NO LO HAS CERRADO, SI LO CIERRAS SE MOSTRARIA EN EL ULTIMA PESTAÑA ABIERTA
            //QUE ES DONDE HAS FINALIZADO EL PAGO...y tendrias q volver a cargar el estado de sesion del cliente a partir del idCliente q le pasas en la url
            res.status(200).redirect(`http://localhost:4200/PedidoResult?idCliente=${idCliente}&idPedido=${idPedido}&opCode=1`);
        }
    },

    //Recuperar producto por id
    RecuperarProducto: async (req: Request, res: Response, next: NextFunction) => {
        try {

            let _idProd = req.query.idProducto;
            console.log('id del producto seleccionado', _idProd) //me sale como undefined pero en el cliente me muestra el id<---solucionado

            await mongoose.connect(process.env.MONGODB_URL!);
            let _producto = await Producto.findById(_idProd);


            res.status(200).send({ codigo: 0, mensaje: 'producto recuperados con exito...', datos: _producto });
        } catch (error) {
            console.log('error al recuperar producto por id....', error);
            res.status(500).send({ codigo: 1, mensaje: 'error al recuperar producto por id... ' + error });
        }
    },

    GuardarOpinion: async (req: Request, res: Response, next: NextFunction) => {
        try {
            //recupero los datos de la opinion
            const { titulo, opinion, puntuacion, estrellas, fechCreacion, tipo, idCliente, idProducto } = req.body;
            console.log('req.body.....', req.body);
            let _nuevaOpinion = new Opinion({
                titulo: titulo,
                opinion: opinion,
                puntuacion: puntuacion,
                estrellas: estrellas,
                fechCreacion: fechCreacion,
                tipo: tipo,
                idCliente: idCliente,
                idProducto: idProducto

            });
            
            console.log('datos recibidos desde angular...,', _nuevaOpinion.titulo);

            //conecto a la base de datos y guardo la opinion
            await mongoose.connect(process.env.MONGODB_URL!);
            let _nuevaOp = await _nuevaOpinion.save();
            console.log('opinion guardada correctamente...', _nuevaOp);

            //ahora tengo que actualizar el producto y el cliente con la nueva opinion
            //1ºProducto
            let _producto = await Producto.findById(idProducto);
            if (!_producto) throw new Error('no se ha encontrado el producto al que se le quiere guardar la opinion...');

            //añado la opinion
            await _producto.valoraciones.push(_nuevaOp._id);
            await _producto.save();
            console.log('producto actualizado...', _producto.valoraciones);

            //2ºCliente
            let _cliente = await Cliente.findByIdAndUpdate(idCliente, {
                $push: { opiniones: _nuevaOp }
            });
            if (!_cliente) throw new Error('no se ha encontrado el cliente al que se le quiere guardar la opinion...');

            //pensaba que esto me daba error y por eso lo cambie a la forma de arriba pero da lo mismo
            //await _cliente.opiniones.push(( _nuevaOp)._id);
            //await  _cliente.save();

            console.log('cliente actualizado...', _cliente.opiniones);

            res.status(200).send({ codigo: 0, mensaje: 'opinion guardada correctamente...', datos: _nuevaOp });
        } catch (error) {
            console.log('error al intentar guardar opinion en node....', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al guardar opinon...' + error })
        }
    },

    RecuperarOpiniones: async (req: Request, res: Response, next: NextFunction) => {
        try {
            let _idProd = req.query.idProducto;
            console.log('valor del idProd, ', _idProd);

            await mongoose.connect(process.env.MONGODB_URL!);

            let _opiniones = await Opinion.find({ idProducto: _idProd });

            console.log('opiniones recuperadas...', _opiniones);

            res.status(200).send({ codigo: 0, mensjae: 'opiniones del producto recuperado con exito', datos: _opiniones })

        } catch (error) {
            console.log('error al recuperar opiniones de un prodcuto', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al recuperar opiniones desde node' + error })
        }
    }


}   