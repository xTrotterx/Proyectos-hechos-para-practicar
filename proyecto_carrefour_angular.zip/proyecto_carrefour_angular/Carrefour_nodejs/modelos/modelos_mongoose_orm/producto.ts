import mongoose from 'mongoose';

const prodSchema=new mongoose.Schema(
    {
        nombre: String,
        imagenes: [ String ],
        pathCategoria: String,
        precio: Number,
        precioKg: Number,
        caracteristicas: String,

        valoraciones:[{type:mongoose.Schema.Types.ObjectId, ref:'Opinion'}]
    }
);
export default mongoose.model('Producto', prodSchema, 'productos');
