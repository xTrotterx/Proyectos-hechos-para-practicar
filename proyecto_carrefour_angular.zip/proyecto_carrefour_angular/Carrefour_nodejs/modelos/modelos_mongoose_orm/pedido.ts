   import mongoose from "mongoose";
   import Producto from './producto';
   import Direccion from "./direccion";
   const pedidoSchema=new mongoose.Schema(
       {
            itemsPedido: [ { producto: Producto.schema, cantidad: Number} ],
            metodoPago: { tipo:String, datosTarjeta: { numeroTarjeta:String, cvv:String, fechaCaducidad:String, nombreTitular:String }},
            direccionEnvio: Direccion.schema,
            direccionFacturacion: Direccion.schema,
            fechaPago: Number,
            fechaEnvio: Number,
            estado: String,
            subtotal: Number,
            gastosEnvio: Number,
            total: Number,
            
       }
   );
   
   export default mongoose.model("Pedido",pedidoSchema, "pedidos")