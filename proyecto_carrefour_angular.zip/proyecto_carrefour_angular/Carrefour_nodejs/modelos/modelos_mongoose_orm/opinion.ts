import mongoose from "mongoose";

const opinionSchema = new mongoose.Schema(
    {
        titulo:{type:String, required: true},
        opinion:String,
        puntuacion:Number,
        estrellas:Number,
        fechCreacion:Number,
        tipo:Number,
        idCliente:{type:mongoose.Schema.Types.ObjectId, ref:'Cliente'},
        idProducto:{type:mongoose.Schema.Types.ObjectId, ref:'Producto'}

        
    }
);
export default mongoose.model("Opinion", opinionSchema, "opiniones");