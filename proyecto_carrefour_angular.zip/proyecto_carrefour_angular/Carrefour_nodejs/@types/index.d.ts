//fichero de extension de tipos....extendemos definicion de interface Request de express
declare global {
    namespace Express {
        interface Request {
            jwtPayload?: any;
        }
    }
}