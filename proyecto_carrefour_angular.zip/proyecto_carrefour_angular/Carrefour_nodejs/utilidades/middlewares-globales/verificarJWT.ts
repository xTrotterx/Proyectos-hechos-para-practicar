import { Request, Response, NextFunction } from 'express';
import jsonwebtoken, { JwtPayload } from 'jsonwebtoken';

export const verificarJWT=(req:Request, res:Response, next: NextFunction)=>{
    try {
        console.log('en func.middleware verificarJWT, headers de peticion que llega...', req.headers);
        
        const authHeader=req.headers['authorization'] as string;
        if (! authHeader) throw new Error('no se ha mandado ningun token de acceso o verificacion, NO HAY CABECERA AUTHORIAZATION!!!');

        const _token=authHeader.split(' ')[1]; //<--- contenido cabecera Authorization: "Bearer adfjlsfdk4934ewjorwfdsfw094s33422342"
        if( !_token) throw new Error('cabecera Authorization mal formada, no hay token despues de Bearer');

        const _claims=jsonwebtoken.verify(_token, process.env.JWT_SECRET!);
        (req as any).jwtPayload=_claims as JwtPayload; //<--- esto kaska si no extiendes interface Request de express (no reconoce esa propiedad)
        next();

    } catch (error) {
        console.log('error en func.middleware verificarJWT', error);
        res.status(401).send( { codigo: 401, mensaje:'error en extraccion de jwt y/o verificacion...' + error });
    }
}
