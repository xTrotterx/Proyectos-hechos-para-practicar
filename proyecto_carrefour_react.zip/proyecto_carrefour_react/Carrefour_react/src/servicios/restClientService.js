export default {
    //#region ---- metodos zona Cliente --------
    ComprobarEmail: async function(email){
        try {
           const _respuesta=await fetch('http://localhost:3003/api/zonaCliente/ComprobarEmail',{
                method:'POST',
                headers: { 'Content-Type':'application/json'},
                body: JSON.stringify({email})
            });
            return _respuesta.json().codigo===0;

        } catch (error) {
            console.log('error al comprobar si existe email...', error);
            throw new Error('error al comprobar si existe email...' + error)
        }
    },
    LoginRegistro: async function(operacion, datosForm){
        try {
            const _respuesta=await fetch(`http://localhost:3003/api/zonaCliente/${operacion}`,{
                 method:'POST',
                 headers: { 'Content-Type':'application/json'},
                 body: JSON.stringify(datosForm)
             });
             return await _respuesta.json();//.codigo===0;
 
         } catch (error) {
             console.log('error en login/registro usuairo...', error);
             return null; //false;
         }
     },
     VerfificarCode: async function(operacion, email, codigo, jwt){
        try {
            const _respuesta=await fetch('http://localhost:3003/api/zonaCliente/VerificarCode',{
                 method:'POST',
                 headers: { 'Content-Type':'application/json'},
                 body: JSON.stringify({ operacion, email, codigo, jwt })
             });
             return await _respuesta.json();//.codigo===0;
 
         } catch (error) {
             console.log('error al verificar codigo 2FA...', error);
             return null; //false;
         }
     },
     //#endregion
     //#region ---- metodos zona Tienda -----
     Categorias: async function(pathCat){
        try {
            const _respuesta=await fetch(`http://localhost:3003/api/zonaTienda/Categorias?pathCat=${pathCat}`);
            let _resp=await _respuesta.json();//<--- { codigo: ..., mensaje: ..., datos: ... };
            
            if(_resp.codigo !== 0  ) throw new Error( _resp.mensaje);
 
            return _resp.datos;

         } catch (error) {
             console.log('error al recuperar categorias...', error);
             return []; //false;
         }   
     },
     Productos: async function({request, params}){ //...loader de objeto Route de react-router-dom
         try {
             console.log('parametros del loader de react-router-dom en RECUPERARPRODUCTOS....', request, params);
             let _resp=await fetch(`http://localhost:3003/api/zonaTienda/Productos?pathCat=${params.pathCat}`);
             let _bodyResp=await _resp.json(); //<---- un objteto: { codigo: x, mensaje: ..., datos: .... }
 
             console.log('productos de categoria...', params.pathCat, _bodyResp)
             return _bodyResp.datos;
 
         } catch (error) {
             console.log('error al recuperar productos...', error.message);
             return null;                        
         }        
     },

     RecuperarProvincias: async function(){
        try {
            let _resp=await fetch('http://localhost:3003/api/zonaTienda/RecuperarProvincias');
            let _bodyResp= await _resp.json();

            console.log('provincias recuperadas correctamente....', _bodyResp.datos);
            if(_bodyResp.codigo !==0) throw new Error(_resp.message);
          
            return _bodyResp.datos.provincias.sort((a,b)=>{
                if(a.PRO < b.PRO) return -1;
                if(a.PRO <b.PRO)return 1;
            })
        } catch (error) {
            console.log('error al llamar al servicio para recuperar provincias...', error);
            return [];
        }
     },
     RecuperarMunis: async function(codProv){
        try{
            let _resp = await fetch(`http://localhost:3003/api/zonaTienda/RecuperarMunis?codProv=${codProv}`);
            let _bodyResp = await _resp.json();

            if (_bodyResp.codigo !== 0) throw new Error(_bodyResp.mensaje);
            console.log('municipios recuperados con exito...', _bodyResp.datos);

            return _bodyResp.datos;

        }catch(error){
            console.log('error al llamar al servicio para recuperar munis ...',error);
            return [];
        }
     },

     InsertarDireccion:async function(idCliente, direcciones){
        try{
               const _pet= await fetch('http://localhost:3003/api/zonaTienda/InsertarDireccion', {
                method:'POST',
                headers:{
                    'Content-Type': 'application/json',
                    body: JSON.stringify(idCliente, direcciones)
                }
            });
            let _resp= await _pet.json()

            if(_resp.codigo !==0) throw new Error(_resp.message);

            return _resp.datos;
            
        }catch(error){
            console.log('error al insertar nueva direccion en coleccion cliente'+error);
            return null;
        }
     },
     /*
     InsertarFranja:async function (envio) {
        try {
            const _pet=await fetch('http://localhost:3003/api/zonaTienda/InsertarFranja', 
                {
                    method:'POST',
                    headers:{'Content-Type': 'application/json'},
                    body: JSON.stringify(envio)
                }
            );
            let _resp = await _pet.json()

            if(_resp.codigo !==0) throw new Error(_resp.message);

            return _resp.datos;
        } catch (error) {
            console.log('error en el servicio para insertar franaj'+ error)
            return null
        }
     }*/

     //#endregion
}