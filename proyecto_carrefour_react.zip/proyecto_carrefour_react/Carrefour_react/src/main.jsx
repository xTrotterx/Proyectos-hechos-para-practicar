import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'

//...hemos instalado localmente bootstrap (en vez de los CDN) con: npm i --save bootstrap @popperjs/core sass
//...Y AHORA IMMPORTAMOS ESTILOS
import '../src/scss/styles.scss'
import * as bootstrap from 'bootstrap'

import './index.css'


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
