const clienteSlice = (set, get, store) => {
    console.log('estamos en clienteSlice...parametros recibidos desde modulo central storeGlobal.js...', set, get, store);
    return {
        codigoVerificacion: '',
        jwt: { sesion: '', refresh: '', verificacion: '' },
        datosCliente: {},
        direcciones: [],
        franjaHorario:{},
        setCodigoVerificacion: codigo => set(state => ({ ...state, codigoVerificacion: codigo })),
        setJwt: (tipo, valorjwt) => set(state => ({ ...state, jwt: { ...state.jwt, [tipo]: valorjwt } })),
        setDatosCliente: newdatosCliente => set(state => ({ ...state, datosCliente: { ...state.datosCliente, ...newdatosCliente } })),
        setDirecciones: (operacion, direccion) => set(
            state => {
                let _direc=[...state.cliente.direcciones];
                switch(operacion){
                    case'insertar':
                    _direc.push(direccion);
                        break;
                    
                    case 'modificar':
                        _direc=_direc.map ((dir,ind)=> ind !== direccion.pos ? dir : direccion);
                        break;

                    default:
                        break;
                }return{
                    ...state,
                    cliente:{
                        ...state.cliente,
                        direcciones:_direc
                    }
                };
            }
        ),
        setFranjaHorario: (franja) => set({ franjaHorario: franja })
    }

}

export default clienteSlice