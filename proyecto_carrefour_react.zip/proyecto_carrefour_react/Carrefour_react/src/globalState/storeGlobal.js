import { create } from 'zustand'
import clienteSlice from './clienteSlice';
import tiendaSlice from './tiendaSlice';
//la funcion "create" de zustand devuelve un HOOK que pueden usar los componentes para recuperar/modificar el objeto 
//metido en el STATE-GLOBAL definido dentro de la funcion "create"

//#region ----- store global en un unico modulo, sin slices ---------------------------
// const useGlobalStore=create(
//     ( set, get, store )=>
//                             {
//                                 console.log('parametros que recibe funcion son:', set, get, store);
//                                 return {
//                                        codigoVerificacion:'',
//                                        jwt: { sesion:'', refresh:'', verificacion:'' },
//                                        datosCliente: { },
//                                        pedido:{
//                                          itemsPedido:[],
//                                          subtotal:0,
//                                          gastosEnvio:0,
//                                          total:0
//                                        },
//                                        //funciones modificacion de props. objeto STATE GLOBAL, NO PUEDEN MUTARLO!!!!! esto no valdria:
//                                        //   setCodigoVerificacion: codigo => set( state => state.codigoVerificacion=codigo) 
//                                        //tienes que sustituir el objeto state por una copia con el valor de la propiedad modificada
//                                        setCodigoVerificacion: codigo => set( state => ({...state, codigoVerificacion: codigo}) ),
//                                        setJwt: (tipo, valorjwt)=> set( state => ({...state, jwt: { ...state.jwt, [tipo]: valorjwt } } ) ),
//                                        setDatosCliente: newdatosCliente => set( state => ({...state, datosCliente:{ ...state.datosCliente, ...newdatosCliente }}) )
                                       
//                                 }
//                             }

// );
//#endregion

//#region --------- store global en modulos o slices ----------------------------
const useGlobalStore=create(
  ( set, get, store ) => {
          console.log('parametros que recibe funcion y q pasamos a cada slice, son:', set, get, store);
          return {
            ...clienteSlice(set,get,store),
            ...tiendaSlice(set,get,store)            
          }

  }
)
//#endregion

export default useGlobalStore;