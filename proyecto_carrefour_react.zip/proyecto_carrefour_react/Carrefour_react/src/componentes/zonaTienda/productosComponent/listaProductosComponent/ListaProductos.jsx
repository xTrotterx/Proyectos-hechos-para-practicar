import './ListaProductos.css'
import { use } from 'react'
import MiniProducto from './miniProductoComponent/MiniProducto';

const ListaProductos=( { productosPromise } )=>{
    //con la funcion use de react obtengo los datos asincronos pasados como propiedad desde comp.padre
    const productos=use(productosPromise);

    return (
        <>
        {
            productos.map( prod => <MiniProducto producto={prod} key={prod._id}></MiniProducto>)
        }
        </>
    )
}

export default ListaProductos;