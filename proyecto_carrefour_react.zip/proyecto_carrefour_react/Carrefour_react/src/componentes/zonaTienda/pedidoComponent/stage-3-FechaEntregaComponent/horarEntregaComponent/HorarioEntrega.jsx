import './HorarioEntraga.css'
import { useState, useEffect, Fragment } from 'react'
import useGlobalStore from '../../../../../globalState/storeGlobal';

const HorarioEntrega = ({ setShowComps }) => {
    const mesActual = Intl.DateTimeFormat('es-ES', { month: 'long' }).format(new Date(Date.now()));
    const franjasHorarias = ['08:00h - 10:00h', '10:00h - 12:00h', '12:00h - 14:00h', '14:00h - 16:00h', '16:00h - 18:00h', '18:00h - 20:00h']
    const [diasSemana, setDiasSemana] = useState({
        0: { diaSemana: 'Domingo', diaMes: 0 },
        1: { diaSemana: 'Lunes', diaMes: 0 },
        2: { diaSemana: 'Martes', diaMes: 0 },
        3: { diaSemana: 'Miercoles', diaMes: 0 },
        4: { diaSemana: 'Jueves', diaMes: 0 },
        5: { diaSemana: 'Viernes', diaMes: 0 },
        6: { diaSemana: 'Sabado', diaMes: 0 }
    });
    const { franjaHorario, setFranjaHorario } = useGlobalStore();
    const [franjaSeleccion, setFranjaSeleccion] = useState({
        diaSemana: franjaHorario?.diaSemana || null,
        mes: franjaHorario?.mes || mesActual,
        franja: franjaHorario?.franja || null
    });

    const gastosEnvio = (diaSemana, franja) => {
        let precio = 6;
        //variable con las horas puntas 
        const horasPunta = ['16:00h - 18:00h', '18:00h - 20:00h'];
        if (horasPunta.includes(franja)) {
            precio = 10;
        }

        // Si el dia es viernes o sabado el gasto sera mayor
        if (diaSemana === 'Viernes' || diaSemana === 'Sabado') {
            precio += 3;
        }

        return precio + ' €';
    };


    
    useEffect(() => {
        const _fechaHoy = new Date();
        const _diaSemanaHoy = _fechaHoy.getDay();

        const nuevoDiasSemana = {};
        for (let i = 0; i <= 6; i++) {
            const refFecha = new Date(_fechaHoy);
            refFecha.setDate(_fechaHoy.getDate() + (i - _diaSemanaHoy));
            nuevoDiasSemana[i] = {
                diaSemana: diasSemana[i].diaSemana,
                diaMes: refFecha.getDate(),
                fechaCompleta: refFecha 
            };
        }
        setDiasSemana(nuevoDiasSemana);
    }, []);

    
    const seleccionarFranja = (iDia, franja) => {
        if (diaNoHabil(iDia)) return; 

        const dia = diasSemana[iDia];
        if (!dia) return;

        setFranjaSeleccion({
            diaSemana: dia.diaSemana,
            mes: mesActual,
            franja
        });
    };

    
    const diaSeleccionado = (iDia, franja) => {
        const dia = diasSemana[iDia];
        return (
            dia?.diaSemana === franjaSeleccion.diaSemana &&
            franja === franjaSeleccion.franja
        );
    };

    //esto deberia de ir un array de arrays ya que no puedo usar bidimensionales

    const obtenerEstadoFranja = (iDia, franja) => {
        const key = `${iDia}_${franja}`;
        const pedidos =  0;
        //estadi concurrido
        if (pedidos >= 5) return 'amarillo'; 
        //estado completo
        if (pedidos >= 10) return 'rojo';     
        return 'verde';                       
    };
  

    const diaNoHabil = (iDia, franja) => {
        const dia = diasSemana[iDia];

        if (!dia || !dia.fechaCompleta) return true;

        const hoy = new Date();
        const diaSinHora = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());

        const fechaDiaSinHora = new Date(
            dia.fechaCompleta.getFullYear(),
            dia.fechaCompleta.getMonth(),
            dia.fechaCompleta.getDate()
        );

        if (dia.diaSemana === 'Domingo') return true;
        if (fechaDiaSinHora < diaSinHora) return true;

        
        const estadoFranja = obtenerEstadoFranja(iDia, franja);
        if (estadoFranja === 'rojo') return true;

        return false;
    };

    const guardarFranja = () => {
        if (franjaSeleccion.diaSemana && franjaSeleccion.franja) {
            setFranjaHorario(franjaSeleccion);
            setShowComps(prev => ({ ...prev, showFechaEntrega: true, showEnvio: false, showHorario: false }));
        } 
    };


    return (
        <div className="container">
            <div className="row m-4">
                <div className="col-md">
                    <h3><strong>{mesActual.toUpperCase()}</strong></h3>
                </div>
            </div>

            <div className="row m-4">
                <div className="col-md">Franja horaria</div>
                {
                    Object.values(diasSemana).map((el, pos) =>
                        <div key={pos} className='col-md'>
                            <div className="d-flex flex-column align-items-center">
                                <span>{el.diaSemana.substring(0, 3)}</span>
                                <span><strong>{el.diaMes}</strong></span>
                            </div>
                        </div>
                    )
                }
            </div>

           
            {
                franjasHorarias.map((franja, posf) =>
                    <div key={posf} className='row m-4'>
                        <div className="col">{franja}</div>
                        {
                            Object.keys(diasSemana).map(iDia => {
                                const diaDeshabilitado = diaNoHabil(Number(iDia), franja);
                                const seleccionado = diaSeleccionado(Number(iDia), franja);
                                const estadoFranja = obtenerEstadoFranja(Number(iDia), franja);

                                
                                let colorDot = diaDeshabilitado ? 'red' :
                                    estadoFranja === 'verde' ? 'green' :
                                        estadoFranja === 'amarillo' ? 'yellow' :
                                            'red';

                                return (
                                    <div
                                        key={`${posf}_${iDia}`}
                                        className="col-md"
                                        onClick={() => seleccionarFranja(Number(iDia), franja)}
                                        style={{
                                            cursor: diaDeshabilitado ? 'not-allowed' : 'pointer',
                                            border: seleccionado ? '2px solid blue' : 'none',
                                            borderRadius: '6px',
                                        }}
                                    >
                                        <div className='d-flex flex-column align-items-center'>
                                            <div>
                                                <span style={{ fontSize: '.93333333rem', fontWeight: '600' }}>
                                                    {diaDeshabilitado ? '-' : gastosEnvio(diasSemana[iDia].diaSemana, franja)}
                                                </span>
                                            </div>
                                            <div>
                                                <span
                                                    className="dot"
                                                    style={{
                                                        backgroundColor: colorDot,
                                                    }}
                                                ></span>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })
                        }
                    </div>
                )
            }

            <div className="row m-4">
                <div className="col-md">
                    <img src="/images/icons_franjas_horaria.png" alt="íconos franjas horarias" />
                </div>
            </div>

            <div className="row m-4">
                <div className="col-md">
                    <div className='m-4 d-flex flex-row align-items-center'>
                        <button className="btn btn-primary btn-lg m-2" onClick={guardarFranja}>GUARDAR FECHA DE ENTREGA</button>
                        <button className="btn btn-outline-primary btn-lg m-2" onClick={() => setShowComps(prev => ({ ...prev, showFechaEntrega: true, showEnvio: false, showHorario: false }))}>Volver atrás sin guardar</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default HorarioEntrega;