import { useEffect, useState, useRef } from 'react'
import useGlobalStore from '../../../../../globalState/storeGlobal'
import './DirEnvio.css'
import restCliente from '../../../../../servicios/restClientService'

const DirEnvio = ({ setShowComps }) => {

    //storeGlobal
    const { datosCliente } = useGlobalStore()
    const setDirecciones = useGlobalStore()
    //esto corresponde al array de direcciones dentro del objeto datosCliente, no tiene por que ser la direccion principal creo !!!!!!!!
    console.log('valor de datos cliente ', datosCliente)
    //para hacerlo bien voy a crear una variable en el state que tenga la direccion principal aunque no se si es necesario
    // no es la direccion principal, es la direccion que estoy mostrando en el modal entendido
    const [direcPrin, setDirecPrin] = useState(datosCliente?.direcciones?.find(d => d.esPrincipal))
    console.log('provincia de la direccion del modal', direcPrin.provincia)
    //muni nno esta vaciooo pero no me lo pinta en la vista voy a matarme y tampoco consigo pintar los municipios
    console.log('municipio de la direccion....', direcPrin.municipio)

    const [municipios, setMunicipios] = useState([]);
    const [muniOption, setMuniOption] = useState({ CMUM: '', CPRO: '', DMUN50: '', CUN: '' })
    const [provincias, setProvincias] = useState([])
    
    const [provsOption, setPorvsOption] = useState({ CPRO: '', PRO: '', CCOM: '' })

    let _selectProvRef = useRef(null); //<----referencia al nodo del dom <select id="inputProvincia"...>
    let _selectMuniRef = useRef(null); //<----referencia al nodo del dom <select id="inputMunicipio"...>


    useEffect(() => {
        // cargar provincias
        restCliente.RecuperarProvincias()
            .then(resp => {
                setProvincias(resp);
                console.log('provincias cargadas:', resp);
            })
            .catch(err => console.log('error al recuperar las provincias', err));

        // si hay dirección principal con provincia, cargar municipios
        if (direcPrin?.provincia?.CPRO) {
            console.log('cargando de municipios de la provincia', direcPrin.provincia.CPRO);
            restCliente.RecuperarMunis(direcPrin.provincia.CPRO)
                .then(resp => {
                    const municipiosArray = Array.isArray(resp) ? resp : [];
                    setMunicipios(municipiosArray);
                    console.log('Municipios cargados:', municipiosArray);
                })
                .catch(err => console.log('error al recuperar los municipios', err));
        }
    }, [direcPrin?.provincia?.CPRO]
)

    
    useEffect(() => {
        //efecto para cuando cambio de provincia 
        if (provsOption.CPRO) {
            console.log('municipios de la provincia....', provsOption.CPRO);
            restCliente.RecuperarMunis(provsOption.CPRO)
                .then(resp => {
                    const municipiosArray = Array.isArray(resp) ? resp : [];
                    setMunicipios(municipiosArray);
                    console.log(' municipios cargados:', municipiosArray);
                    
                    // Actualizar la dirección principal con la nueva provincia
                    setDirecPrin(prev => ({
                        ...prev,
                        provincia: {
                            CPRO: provsOption.CPRO,
                            PRO: provsOption.PRO,
                            CCOM: provsOption.CCOM
                        },
                        municipio: null // Limpiar municipio al cambiar provincia
                    }));
                })
                .catch(err => console.log('error al recuperar municipios', err));
        }
    }, [provsOption.CPRO]);

    useEffect(() => {
        // efecto para manejar cambios en el municipio seleccionado

        if (muniOption.CMUM) {
            setDirecPrin(prev => ({
                ...prev,
                municipio: {
                    CMUM: muniOption.CMUM,
                    CPRO: muniOption.CPRO,
                    DMUN50: muniOption.DMUN50,
                    CUN: muniOption.CUN
                }
            }));
        }
    }, [muniOption]);

    //iba a intentar hacer la funcion para guardar los datos adicionales pero me esta dando bastantes problemas

    const Guardar = async () => {
        try {
            setDirecciones(direcPrin);
            const _insert = await restCliente.InsertarDireccion(datosCliente._id, datosCliente.direcciones);
            console.log('codigo del insert', _insert.codigo)

        } catch (error) {
            console.log('error al hacer la inserccion a node')
        }
    };



    return (
        <div className="container">
            <div className="row">
                <div className="col-md">
                    <div className="card">
                        <div className="card-body">
                            {/* ---------------------- fila municipios y provincias ------------------------ */}
                            <div className="row g-2 mb-3 mt-3">
                                <div className="col-md">
                                    <div className="form-floating">
                                        <select className="form-select" id="selectLocalidad"
                                            value={direcPrin?.municipio
                                                ? `${direcPrin.municipio.CPRO}-${direcPrin.municipio.CMUM}-${direcPrin.municipio.DMUN50}-${direcPrin.municipio.CUN}`
                                                : ''
                                            }
                                            ref={_selectMuniRef}
                                            onChange={(ev) => {
                                                const [CPRO, CMUM, DMUN50, CUN] = ev.target.value.split('-');
                                                setMuniOption({ CMUM, CPRO, DMUN50, CUN });
                                            }}
                                        >
                                            <option value="">Selecciona Localidad</option>
                                            {municipios.map((muni, pos) => (
                                                <option key={pos}
                                                    value={`${muni.CPRO}-${muni.CMUM}-${muni.DMUN50}-${muni.CUN || ''}`}
                                                >
                                                    {muni.DMUN50}
                                                </option>
                                            ))}
                                        </select>
                                        <label for="selectLocalidad">Works with selects</label>
                                    </div>
                                </div>

                                <div className="col-md">
                                    <div className="form-floating">
                                        <select className="form-select" id="selectProvincia"
                                            value={direcPrin?.provincia
                                                ?
                                                `${direcPrin.provincia.CCOM}-${direcPrin.provincia.CPRO}-${direcPrin.provincia.PRO}`
                                                :
                                                ''}
                                            ref={_selectProvRef}
                                            onChange={(ev) => {
                                                const [CCOM, CPRO, PRO] = ev.target.value.split('-');
                                                setPorvsOption({ CPRO, PRO, CCOM });
                                            }}
                                        >
                                            <option value="">Selecciona Provincia</option>
                                            {provincias.map((prov, pos) => (
                                                <option key={pos} value={`${prov.CCOM}-${prov.CPRO}-${prov.PRO}`}>
                                                    {prov.PRO}
                                                </option>
                                            ))}
                                        </select>
                                        <label for="selectProvincia">Works with selects</label>
                                    </div>
                                </div>
                            </div>
                            {/* ---------------------- fila cp -------------------------------------------- */}
                            <div className="row g-2 mb-3">
                                <div className="col-md">
                                    <div className="form-floating">
                                        <input type="text" className="form-control" id="txtCP" placeholder="codigo postal"
                                            value={direcPrin.cp}
                                            onChange={(ev) => setDirecPrin({ ...direcPrin, cp: ev.target.value })}
                                        />
                                        <label for="txtCP">CP *</label>
                                    </div>
                                </div>
                            </div>
                            {/* ---------------------- fila Direccion -------------------------------------------- */}
                            <div className="row g-2 mb-3">
                                <div className="col-md">
                                    <div className="form-floating">
                                        <input type="text" className="form-control" id="txtDireccion" placeholder="Calle o Avenida, numero, piso, etc..."
                                            value={direcPrin.calle.calleCompleta}
                                            onChange={(ev) => setDirecPrin({
                                                ...direcPrin,
                                                calle: {
                                                    ...direcPrin.calle,
                                                    calleCompleta: ev.target.value
                                                }
                                            })}
                                        />
                                        <label for="txtDireccion">Direccion *</label>
                                    </div>
                                </div>
                            </div>
                            {/* ---------------------- boton para mostrar modal añadir mas datos a direccion: numero, bloque, ... --------- */}
                            <div className="row g-2 mb-3">
                                <div className="col-md align-items-start">
                                    <span data-bs-toggle="modal" data-bs-target="#staticBackdrop" style={{ 'color': '#0077e2', 'fontSize': '.93333333rem', 'fontWeight': '600', 'cursor': 'pointer' }}><i className="fa-solid fa-circle-plus"></i>{' '} Añadir mas datos de direccion</span>
                                </div>
                                {/* modal... */}
                                <div className="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div className="modal-dialog">
                                        <div className="modal-content">
                                            <div className="modal-header">
                                                <h1 className="modal-title fs-5" id="staticBackdropLabel">Mas datos de direccion</h1>
                                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div className="modal-body">
                                                {
                                                    ["Numero", "Bloque", "Escalera", "Piso", "Puerta", "Urbanizacion"].map(
                                                        (el, pos, arr) => (
                                                            <div className="form-floating mb-3" key={pos}>
                                                                <input type="text"
                                                                    className="form-control"
                                                                    id={`text-${el}`}
                                                                    placeholder={el}
                                                                    value={direcPrin.calle?.[el.toLowerCase()] || ''}
                                                                    onChange={(ev) => setDirecPrin({
                                                                        ...direcPrin,
                                                                        calle: {
                                                                            ...direcPrin.calle,
                                                                            [el.toLowerCase()]: ev.target.value
                                                                        }
                                                                    })}
                                                                />
                                                                <label for={`text-${el}`}>{el}</label>
                                                            </div>
                                                        )
                                                    )
                                                }
                                            </div>
                                            <div className="modal-footer d-flex flex-column align-items-center">
                                                <button type="button" className="btn btn-primary w-100">Guardar Cambios</button>
                                                <button type="button" className="btn btn-outline-primary w-100" data-bs-dismiss="modal">Cancelar cambios</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='m-4 d-fex flex-row align-items-center'>
                        <button className="btn btn-primary btn-lg m-2" onClick={Guardar}>GUARDAR DIRECCION</button>
                        <button className="btn btn-outline-primary btn-lg m-2" onClick={(ev) => setShowComps(prev => ({ ...prev, showFechaEntrega: true, showEnvio: false, showHorario: false }))}>Volver atras sin guardar</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default DirEnvio;