import './FechaEntrega.css'
import { useState } from 'react'
import DirEnvio from './dirEnvioComponent/DirEnvio';
import HorarioEntrega from './horarEntregaComponent/HorarioEntrega';
import { useEffect } from 'react';
import useGlobalStore from '../../../../globalState/storeGlobal'

const FechaEntrega = () => {
    const [showComps, setShowComps] = useState({ showFechaEntrega: true, showEnvio: false, showHorario: false })
    
    const { datosCliente } = useGlobalStore();
    const{franjaHoraria}=useGlobalStore();

    const [conValor, setConValor] = useState(false);
  
    const [direc, setDirec] = useState({
        calle: '',
        municipio: '',
        provincia: '',
        cp: '',
        numero: '',
        bloque: '',
        escalera: '',
        piso: '',
        puerta: '',
        urbanizacion: ''
    });

    useEffect(() => {
        if (datosCliente.direcciones && datosCliente.direcciones.length > 0) {
            
            let direccion = datosCliente.direcciones.find(dir => dir.esPrincipal);
            
            if (direccion) {
                //para meter la direccion principal
                setDirec({
                    calle: direccion.calle?.calleCompleta ?? 'No disponible',
                    municipio: direccion.municipio?.DMUN50 ?? 'No disponible',
                    provincia: direccion.provincia?.PRO ?? 'No disponible',
                    cp: direccion.cp ?? 'No disponible',
                    numero: direccion.calle?.numero ?? 'No disponible',
                    bloque: direccion.calle?.bloque ?? 'No disponible',
                    escalera: direccion.calle?.escalera ?? 'No disponible',
                    piso: direccion.calle?.piso ?? 'No disponible',
                    puerta: direccion.calle?.puerta ?? 'No disponible',
                    urbanizacion: direccion.calle?.urbanizacion ?? 'No disponible'
                });
                setConValor(true);
                console.log(conValor)
                console.log('direccion encontrada:', direccion);
            } else {
                // tiene direcciones pero no principales
                setConValor(false);
            }
        } else {
            // si no hay direcciones
            setConValor(false);
        }
    }, [datosCliente.direcciones]);

    
    //me da problemas
    //esto me carga directamente la direccion principal
    /*const [direccion,setDireccion]=useState()
    console.log('ninnionionio', direccion);
    const dir = datosCliente.direcciones?.find(d => d.esPrincipal);
    if (dir) {
        {
            setDireccion({
                calle: dir.calle?.calleCompleta ?? 'No disponible',
                municipio: dir.municipio?.DMUN50 ?? 'No disponible',
                provincia: dir.provincia?.PRO ?? 'No disponible',
                cp: dir.cp ?? 'No disponible',
                numero: dir.calle.numero ?? 'No disponible',
                bloque: dir.calle.bloque ?? 'No disponible',
                escalera: dir.calle.escalera ?? 'No disponible',
                piso: dir.calle.piso ?? 'No disponible',
                puerta: dir.calle.puerta ?? 'No disponible',
                urbanizacion: dir.calle.urbanizacion ?? 'No disponible'

            })
        }
    }*/

    return (
        <div className='container'>
            <div className="row m-4">
                <div className="col d-flex flex-column align-items-start">
                    <h3>Entrega y horario</h3>
                    <p>Revisa tus datos para poder realizar el pedido</p>
                </div>
            </div>

            {
                showComps.showFechaEntrega ?
                    (
                        <div className="row m-4">
                            {/* ... añadir/modificar direccion envio... */}
                            <div className="col-md">
                                <div className="card">
                                    <div className="card-body">
                                        <div className="card-title d-flex flex-row justify-content-between">
                                            <h5><i class="fa-solid fa-truck-fast"></i>{' '}Envio a Domicilio</h5>
                                            <span

                                                onClick={(ev) =>
                                                    setShowComps((prev) => ({
                                                        ...prev,
                                                        showFechaEntrega: false,
                                                        showEnvio: true,
                                                        showHorario: false
                                                    }))
                                                }
                                                style={{
                                                    color: '#0077e2',
                                                    fontSize: '.93333333rem',
                                                    fontWeight: '600',
                                                    cursor: 'pointer',
                                                }}
                                            >
                                                {conValor ? 'Modificar' : 'Crear'}
                                            </span>
                                        </div>
                                        <div className="card-text">
                                            {conValor ? (
                                                <>
                                                    Calle:{direc.calle}<br />
                                                    Municipio: {direc.municipio} <br />
                                                    Provincia:{direc.provincia}<br />
                                                    Cp: {direc.cp} <br />
                                                    Numero: {direc.numero}<br />
                                                    Bloque: {direc.bloque}<br />
                                                    Escalera: {direc.escalera}<br />
                                                    Piso: {direc.piso}<br />
                                                    Puerta: {direc.puerta}<br />
                                                    Urbanizacion: {direc.urbanizacion}<br />

                                                </>
                                            ) :
                                                (
                                                    <p> no tienes direcciones </p>
                                                )}

                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* ... añadir/modificar Horario de entraga... */}
                            <div className="col-md">
                                <div className="card">
                                    <div className="card-body">
                                        <div className="card-title d-flex flex-row justify-content-between">
                                            <h5><i class="fa-regular fa-clock"></i>{' '}Horario de entrega</h5>
                                            <span 
                                            onClick={(ev) => setShowComps(prev => ({ ...prev, showFechaEntrega: false, showEnvio: false, showHorario: true }))}
                                             style={{ 'color': '#0077e2', 'fontSize': '.93333333rem', 'fontWeight': '600', 'cursor': 'pointer' }}>Modificar/Crear {'>'}</span>
                                        </div>
                                        <div className="card-text">
                                                    {
                                                franjaHoraria
                                                    ? `Modificar tu envio: ${franjaHoraria.diaSemana} ${franjaHoraria.mes} ${franjaHoraria.franja}`
                                                    : "haz un pedido"
                                            }

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                    : (
                        <>
                            <div className="row m-4">
                                <div className="col-md d-flex flex-row justify-content-between">
                                    <button type="button"
                                        className='btn btn-outline-primary'
                                        disabled={showComps.showEnvio == true}
                                        onClick={(ev) => setShowComps(prev => ({ ...prev, showFechaEntrega: false, showEnvio: true, showHorario: false }))}
                                    ><img src="/images/boton_Envio_Domicilio.png"></img>
                                    </button>
                                    <button type="button"
                                        className='btn btn-outline-primary'
                                        disabled={showComps.showHorario == true}
                                        onClick={(ev) => setShowComps(prev => ({ ...prev, showFechaEntrega: false, showEnvio: false, showHorario: true }))}
                                    ><img src="/images/boton_Recogida_Horaria.png"></img>
                                    </button>
                                </div>
                            </div>
                            <div className='row m-4'>
                                <div className="col-md">
                                    {showComps.showEnvio && <DirEnvio setShowComps={setShowComps} />}
                                    {showComps.showHorario && <HorarioEntrega setShowComps={setShowComps} />}

                                </div>
                            </div>
                        </>
                    )
            }
        </div>

    )
};

export default FechaEntrega;