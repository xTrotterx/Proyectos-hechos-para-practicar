import './DatosContacto.css'

const DatosContacto=()=>{

    return (
        <>
        <h3>estas en DatosContacto...</h3>
        </>
    )
};

export default DatosContacto;