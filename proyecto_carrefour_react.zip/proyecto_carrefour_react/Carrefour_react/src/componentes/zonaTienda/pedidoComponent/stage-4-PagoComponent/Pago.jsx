import './Pago.css'

const Pago=()=>{

    return (
        <>
        <h1>estas en Pago...</h1>
        </>
    )
};

export default Pago;