import './InicioPanel.css'
import useGlobalStore from '../../../../globalState/storeGlobal';
import { useNavigate } from 'react-router-dom';

const InicioPanel=()=>{
    const { datosCliente }=useGlobalStore();
    const navigate=useNavigate();

    console.log('datos de cliente...', datosCliente);

    return (
        <div className="container">
            <div className="row m-4">
                <div className="col">
                    { datosCliente._id ? JSON.stringify(datosCliente) : <p>...sin datos del cliente...</p> }
                </div>
            </div>
            <div className="row m-4">
                <div className="col-md">
                    <button className="btn btn-primary btn-lg" onClick={()=>navigate('/')}>IR A LA TIENDA</button>
                </div>
            </div>
        </div>
    )
}

export default InicioPanel;