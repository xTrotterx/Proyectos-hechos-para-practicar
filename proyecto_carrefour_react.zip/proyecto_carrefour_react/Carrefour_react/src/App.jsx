import './App.css'
import {createBrowserRouter, RouterProvider} from 'react-router-dom' //<--- funcion del paquete react-router-dom q admite como parametro un array de objetos
//RouteObject q mapean url obtenidas del navegador con componentes a cargar
//props de estos objetos: path <---- url q chequea el modulo de enrutamiento con la url navegador
//                       element <--- componente a cargar si se encuentra la url en path
//                       children <--- array de objetos route HIJOS para este path (anidar rutas)

//objeto RouterObject devuelto por metodo createBrowserRouter que exponemos al resto de componentes con
//componente especifico de react-router-dom: <RouterProvider router={...objeto router...}></RouterProvider>
import Login from  './componentes/zonaCliente/loginComponent/Login'
import Registro from './componentes/zonaCliente/registroComponent/Registro'
import Verficar2FAcode from './componentes/zonaCliente/verificar2FAComponent/Verificar2FAcode'
import Layout from './componentes/zonaTienda/layOutComponent/Layout'
import Home from './componentes/zonaTienda/homeComponent/Home'
import restClientService from './servicios/restClientService'
import Productos from './componentes/zonaTienda/productosComponent/Productos'
import Pedido from './componentes/zonaTienda/pedidoComponent/Pedido'
import InicioPanel from './componentes/zonaCliente/PanelCliente/inicioPanelComponent/InicioPanel'

const routerObject=createBrowserRouter(
    [
      { path: '/Pedido', element: <Pedido></Pedido>}, 
      {
        element: <Layout/>,
        children:[
          { path:'/', element: <Home/> },
          { path:'/Tienda',
            children:[
              //{ path: 'Productos/:pathCat', element: <Productos></Productos>, loader: restClientService.Productos }
              { path: 'Productos/:pathCat', element: <Productos/> }
            ]
          }
          
        ]
      },
      {
        path:'/Cliente',
        children:[          
          { path:'Login', element: <Login/> },
          { path:'Registro', element: <Registro/> },
          { path:'Verificar/:operacion', element: <Verficar2FAcode/> },
          { path: 'Panel', 
            children:[
              { path:'Inicio', element: <InicioPanel></InicioPanel>}
            ]
          }
        ]
      },
    ]
  )

function App() {

  return (
    <>
      <RouterProvider router={routerObject}></RouterProvider>
    </>
  )
}

export default App
