const mongoose=require('mongoose');
const bcrypt=require('bcrypt');
const jsonwebtoken=require('jsonwebtoken');

const miMailJetService=require('../../../servicios/MailJet');


const Direccion=require('../../../modelos/direccion');
const Provincia=require('../../../modelos/provincia');
const Municipio=require('../../../modelos/municipio');
const Cliente=  require('../../../modelos/cliente');
const Pedido=   require('../../../modelos/pedido');


module.exports={
    Login: async (req,res,next)=>{
        try {
            const { email, password }=req.body;
    
            //1º compruebo si existe cliente con ese email...
            await mongoose.connect(process.env.MONGODB_URL)
            let _cliente=await Cliente.findOne({'cuenta.email': email}).lean();
            if( ! _cliente) throw new Error('no existe cliente asociado a ese email');
    
            //2º compruebo password ok...
            if (! bcrypt.compareSync(password, _cliente.cuenta.password) ) throw new Error('password incorrecta')
            
            //3º generar codigo verfificacion 2fa, mandar email y respuesta...
            const _codigo=crypto.randomUUID().substring(0,6);
            const _jwtVerificacion=jsonwebtoken.sign( { email, codigo: _codigo }, process.env.JWT_SECRET, { issuer: 'http://localhost:3003', expiresIn:'15m' });
    
            //...plantilla email, y envio del email atraves del servicio....
    
            res.status(200).send({codigo:0, mensaje:'login ok', datos:{ codigo: _codigo, jwt: _jwtVerificacion, datosCliente: _cliente}});
    
        } catch (error) {
            console.log('error en login...', error);
            res.status(200).send({ codigo: 1, mensaje:'error en login: ' + error });
        }
    },
    Registro: async (req,res,next)=>{
        try {
            console.log('estas en endpoing /api/zonaCliente/Registro ... y los datos que hay en el body son: ', req.body);
            const { nombre, apellidos, telefono, email, password, cp='', tipoDocumento:tipo, dninif:valor }=req.body;
    
            // 1º ---- registrar datos del cliente en coleccion "clientes" usando mongoose....
            await mongoose.connect(process.env.MONGODB_URL);
            let _resultInsertCliente=await (
                                        new Cliente(
                                            {
                                                nombre,
                                                apellidos,
                                                telefono,
                                                tarjetaCarrefour: new Date(Date.now()).getTime(),
                                                cp,
                                                documento: { tipo, valor },
                                                cuenta: { email, password: bcrypt.hashSync(password,10) },
                                                direcciones: [],
                                                pedidos: [],
                                                activada: false
                                            }
                                        )
                                ).save();
            console.log('datos cliente insertados...', _resultInsertCliente);
    
            // 2º ---- generacion de codigo aleatorio de 6 caracteres, generaion JWT de comprobacion y envio del mismo al email del usuario....
            const _code=crypto.randomUUID().substring(0,6);
            const _jwt=jsonwebtoken.sign({ email, codigo:_code }, process.env.JWT_SECRET);
    
            const _mailTemplate=`
                    <div>
                        <p>Bienvenido a nuestra Tienda Carrefour Online, puedes descargarte nuesta app para moviles tambien</p>
                        <p>para hacer la compra lo mas facil posible. </p>
                        <br/>
                        <p>Ten en cuenta tu numero de tarjeta Carrefour: ${_resultInsertCliente.tarjetaCarrefour}</p>
                        <h4>Verifica tu cuenta de Carrefour, introduciendo este codigo: <strong>${_code}</strong></h4>
                    </div>
            `;
    
            await miMailJetService.EnviarEmail(email, 'Verifica tu cuenta mandando codigo a Carrefour', '',_mailTemplate);
    
            //---------------------------------------------------------------------------------------
            res.status(200).send({ codigo: 0, mensaje:'Registro ok, envio de codigo de verificacion', datos: { email, codigo: _code, jwtVerificacion: _jwt } } );
    
        } catch (error) {
            console.log('estas en endpoing /api/zonaCliente/Registro ... y los datos que hay en el body son: ', req.body);
            res.status(200).send({ codigo:1, mensaje: 'Error en Registro...'});
    
        }
    
    },
    VerificarCode: async (req,res,next)=>{
        try {
        //en req.body me manda react estos datos: { operacion='Registro o Login', email:..., codigo: ...., jwt: jwt_verificacion }
        const { operacion, email, codigo, jwt } = req.body;
    
        //1º verificamos jwt esta firmado por mi server con metodo .verify de jsonwebtoken si no lo esta, excepcion si lo esta extrae claims del mismo..
        const _payload=jsonwebtoken.verify(jwt,process.env.JWT_SECRET); //<--- si todo ok, esta code y email
    
        //2º verificamos q email y codigo enviados coinciden con email y codigo del jwt, sino excepcion
        if( _payload.email !== email || _payload.codigo !== codigo ) throw new Error('email o codigo incorrectos, intentalo con nuevo codigo');
    
        //3º si todo ok en funcion de operacion, si estamos en registro activamos cuenta si estamos en login generamos tokens de session, refresh y
        //  devolvemos datos cliente
        let _datos;
    
        if (operacion==='Registro') {
            let _resp=await Cliente.updateOne( {'cuenta.email': email }, { $set: { 'activada': true} } );
            if (_resp.modifiedCount !== 1 ) throw new Error('error interno en mongoDB a la hora de activar cuenta');
            
        } else {
            //recupero datos del cliente expandiendo propiedades direcciones, pedidos, .... aquellas q almacenen los _ids de ref. a otros documentos de otras colecciones
            //los join a otras colecciones
            let _datosCliente=await Cliente.findOne({'cuenta.email': email}).lean();
                                            //.populate(
                                            //    [
                                                    // { path: 'direcciones', 
                                                    //   model: Direccion,
                                                    //   populate: [
                                                    //         { path: 'provincia', model: Provincia },
                                                    //         { path: 'municipio', model: Municipio }
                                                    //     ] 
                                                    // },
                                                    //{ path: 'pedidos', model: Pedido }
                                                //]
                                            //).lean() ;
            if (!_datosCliente ) throw new Error('error al verificar codigo, no existe cliente con ese email');
    
            let _jwtSesion=jsonwebtoken.sign({ tipo:'sesion', idCliente: _datosCliente._id.toString(), email }, process.env.JWT_SECRET, { issuer: 'http://localhost:3003', expiresIn: '1h'});
            let _jwtRefresh=jsonwebtoken.sign({ tipo:'refresh', idCliente: _datosCliente._id.toString() }, process.env.JWT_SECRET, { issuer: 'http://localhost:3003', expiresIn: '4h'});
            _datos={ jwt:{ 'sesion': _jwtSesion, 'refresh': _jwtRefresh}, datosCliente: _datosCliente }
        }
    
        res.status(200).send({codigo:0, mensaje:'validacion codigo 2fa correcto', datos: _datos });
            
        } catch (error) {
            console.log('error en verificacio codigo...', error);
            res.status(200).send({codigo:1, mensaje:'error validacion codgio: ' + error });
    
        }
    
    
    }

}