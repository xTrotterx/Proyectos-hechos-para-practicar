const mongoose = require('mongoose');
const Categoria = require('../../../modelos/categoria');
const Producto = require('../../../modelos/producto');
const Cliente = require('../../../modelos/cliente');


module.exports = {
    Categorias: async (req, res, next) => {
        try {
            //...pasamos en la query la categoria a seleccionar, parametro pathCat <--- si vale "raices" pues recupero
            //categorias principales, sino las subcategorias de esa categoria...

            let pathCat = req.query.pathCat;

            let _pattern = '^\\d+$';
            if (pathCat !== 'raices') _pattern = `${pathCat}-(\\d+-?)`;

            let _regex = new RegExp(_pattern);

            await mongoose.connect(process.env.MONGODB_URL);
            let _cats = await Categoria.find({ pathCategoria: { $regex: _regex } });
            //console.log('categorias de...', pathCat, _cats);

            res.status(200).send({ codigo: 0, mensaje: 'categorias recuperadas ok...', datos: _cats });

        } catch (error) {
            console.log('error recuperar categorias  ', error);
            res.status(200).send({ codigo: 1, mensaje: 'error recuperando categorias ...' + error });

        }
    },
    Productos: async (req, res, next) => {
        try {
            let pathCat = req.query.pathCat;

            await mongoose.connect(process.env.MONGODB_URL);
            let _prods = await Producto.find({ pathCategoria: pathCat });
            //console.log('productos de...', pathCat, _prods);

            res.status(200).send({ codigo: 0, mensaje: 'productos recuperados ok...', datos: _prods });
        } catch (error) {
            console.log('error al recuperar productos de categoria: ', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al recuperar productos de categoria: ' + error });
        }
    },

    RecuperarProvincias: async (req, res, next) => {
        try {
            await mongoose.connect(process.env.MONGODB_URL)
            let _resProvs = await mongoose.connection.db
                .collection('provincias')
                .find();

            let _provs = await _resProvs.toArray();

            console.log('provincias...', _provs);
            res.status(200).send({ codigo: 0, mensaje: 'provincias recuperadas con exito', datos: { provincias: _provs } });

        } catch (error) {
            console.log('error al intentar recuperar provincias: ', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al recuperar provincias' });
        }
    },
    RecuperarMunis: async (req, res, next) => {
        let _codProv = req.query.codProv;

        try {
            //1º compruebo que el codigo de provincia coincida 
            await mongoose.connect(process.env.MONGODB_URL)

            let _resProv = await mongoose.connection.db
                .collection('provincias')
                .findOne({ CPRO: _codProv });
            if (!_resProv) throw new Error("no existe una provincia con ese codigo de provincia ...");

            let _resMunis = await mongoose.connection.db
                .collection('municipios')
                .find({ CPRO: _codProv });

            let _munis = await _resMunis.toArray();

            console.log(`municipios de provincia: ${_resProv.PRO}...`, _munis);
            res.status(200).send({ codigo: 0, mensaje: 'municipios recuperados con exito', datos: { municipios: _munis } });

        } catch (error) {
            console.log('error al intentar recuperar municipios', error);
            res.status(200).send({ codigo: 1, mensaje: 'error al recuperar municpios' });

        }
    },


    InsertarDireccion: async (req, res, next) => {
        try {
            console.log('parametros recibidos del body...', req.body);
            //esto creo que lo hicimos un dia en clase que era para limpiar de datos innecesrio la direccion
            const { idCliente, direcciones } = req.body;
            

            await mongoose.connect(process.env.MONGODB_URL)
            const _resp = await mongoose.connection.db
                .collection('clientes')
                .findOneAndUpdate(
                    { _id: new mongoose.Types.ObjectId(idCliente) },
                    { $set: { 'cliente.direcciones': direcciones } },
                    {returnDocument:'after'}
                );
            
            
            console.log('cliente actualizado con nuevas direcciones...', _resp)

            res.status(200).send({ codigo: 0, mensaje: 'direccion insertada con exito' });

        } catch (error) {
            console.log('error al insertar direccion en cliente...', error);
            res.status(200).send({ codigo: 2, mensaje: 'error al actualizar el cliente' +error.message});
        }
    }
}