const express=require('express');
const clienteEPController = require('./endpointsControllers/clienteEPController');

// me gustaria especificar para la url /api/zonaCliente diferentes endpoints a los que se accede por diferentes metodos http, como POST,GET...
// ademas estos endpoints pueden tener segmentos en la url variables /api/zonaCliente ----> /ObtenerPedido/:idPedido
//entonces en vez de poner directemente una funcion middleware sobre la url /api/zonaCliente, se incrusta un objeto express.Router()
const routingCliente=express.Router();


routingCliente.post('/Registro', clienteEPController.Registro);
routingCliente.post('/Login', clienteEPController.Login);
routingCliente.post('/VerificarCode', clienteEPController.VerificarCode);


module.exports=routingCliente;