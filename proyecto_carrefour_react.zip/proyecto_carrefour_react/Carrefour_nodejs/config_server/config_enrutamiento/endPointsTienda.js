const express=require('express');
const tiendaEPController = require('./endpointsControllers/tiendaEPController');

// me gustaria especificar para la url /api/zonaTienda diferentes endpoints a los que se accede por diferentes metodos http, como POST,GET...
const routingTienda=express.Router();

routingTienda.get('/Categorias', tiendaEPController.Categorias );
routingTienda.get('/Productos', tiendaEPController.Productos );

//endpoints del examen
routingTienda.get('/RecuperarProvincias', tiendaEPController.RecuperarProvincias);
routingTienda.get('/RecuperarMunis', tiendaEPController.RecuperarMunis );

routingTienda.post('/InsertarDireccion', tiendaEPController.InsertarDireccion);

module.exports=routingTienda;