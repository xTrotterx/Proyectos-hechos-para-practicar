
//modulo de codigo node q exporta una funcion q recibe como parametro el objeto servidor Express a configurar
//su PIPELINE (conjuto de funciones middleware, incluidas las de enrutamiento)
const express=require('express');
const cors=require('cors');

const routingCliente=require('./config_enrutamiento/endPointsCliente');
const routingTienda=require('./config_enrutamiento/endPointsTienda');


module.exports=function(servidorWebExpress){
/*--------- configuracion PIPELINE servidor de EXPRESS -----------------------------
  la pipeline la conforman un conjunto de funciones javascript llamadas funciones MIDDLEWARE q tienen este formato: admiten de forma obligatoria
  tres parametros:
        - 1º parametro objeto HttpRequest o "req" <--- representa objeto HTTP-CLIENT-REQUEST o peticion del cliente q llega al servidor
        - 2º parametro objeto HttpResponse o "res" <-- representa objeto HTTP-RESPONSE o respuesta que da el servidor al cliente
        - 3º parametro funcion NextHandler o "next" <--- funcion que al invocarse NO DEVUELVE RESPUESTA AL CLIENTE, invoca a siguiente funcion
                                                        middleware dentro de la pipeline
  funcion middleware:
  ===================          
    (req,res,next)=>{   
            ...
            o devuelve respuesta con objeto: res
            o invoca a siguiente funcion middleware con funcion: next
        }

    la pipeline esta formada por un conjunto de estas funciones:
    =============================================================
        funcion-mid-1           funcion-mid-2                funcion-mid-3
    (req,res,next)=>{       |--> (req,res,next)=>{      | --> (req,res,next)=>{
        ....                |           ...             |       ...
        }   ----------------|   } ----------------------|       }
            |                       |
            | puede generar         |
    <-------- respuesta             | puede generar
    <-------------------------------- respuesta

*/

servidorWebExpress.use(express.json()); //<----  funcion-mid-1: primera funcion middleware dentro de la pipeline para extraer del body de las pet. objetos JSON y lo mete
                         //dentro de prop. req.body
servidorWebExpress.use(express.urlencoded({extended:false})); //<--- funcion-mid-2:  segunda funcion middleware dentro de la pipeline q extrae de la url variables 
                                              // pasadas por GET, las mete dentro de req.query

servidorWebExpress.use(cors()); //<----------- funcion-mid-3: el resultado de la ejecucion de la funcion cors() devuelve una funcion middleware que incrustamos
                 //dentro de la pipeline


//incrusto objeto Router en la pipeline de express para url '/api/zonaCliente y '/api/zonaTienda'
servidorWebExpress.use('/api/zonaCliente', routingCliente);
servidorWebExpress.use('/api/zonaTienda', routingTienda);

}