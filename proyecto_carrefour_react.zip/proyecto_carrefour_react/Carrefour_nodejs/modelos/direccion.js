const mongoose = require("mongoose");

const direccionSchema=new mongoose.Schema(
    {
        calle: { 
            calleCompleta: String,
            numero: String,
            bloque: String,
            escalera: String,
            piso: String,
            puerta: String,
            urbanizacion: String
         },
        cp: { type: String, required: true, match:/^\\d{5}$/, default:'00000' },
        provincia: { type: mongoose.Schema.Types.ObjectId, ref: 'Provincia' }, //<--- se podria almacenar el objeto entero...
        municipio: { type: mongoose.Schema.Types.ObjectId, ref: 'Municipio' },
        esPrincipal: { type: Boolean, default: false },
        esFacturacion: { type: Boolean, default: false },
        datosContacto: {
                            nombre: String, 
                            apellidos: String, 
                            telefono: String, 
                            documento:{ tipo:String, valor: String },
                            email: String
                        }
    }
);

module.exports= mongoose.model("Direccion", direccionSchema, "direcciones")