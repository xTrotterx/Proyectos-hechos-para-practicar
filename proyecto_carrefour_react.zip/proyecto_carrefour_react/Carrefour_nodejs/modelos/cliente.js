const mongoose = require('mongoose');
const Direccion = require('./direccion');

// Definir el esquema para la colección 'clientes'
const cuentaSchema = new mongoose.Schema(
    {
        nombre: { type: String, required: true },
        apellidos: { type: String, required: true },
        telefono: { type: String, required: false },
        tarjetaCarrefour: { type: String, required: true },
        documento: { 
                        tipo: { 
                                    type: String,
                                    required: true
                                 },
                        valor: {
                                 type: String,
                                 required: true
                                 }
                    },
        cp: { type: String, required: false },
        activada: { type: Boolean, default: false },
        cuenta: { 
                    email: { 
                                type: String,
                                required:true 
                            },
                    password: { 
                                type: String,
                                required:true
                             }
                },
        direcciones:  [  Direccion.schema ],
        pedidos: [] 
    }, 
);

// Crear el modelo basado en el esquema

module.exports = mongoose.model('Cliente', cuentaSchema, 'clientes');
 