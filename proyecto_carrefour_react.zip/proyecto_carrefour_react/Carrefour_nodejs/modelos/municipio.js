const mongoose = require("mongoose");

const municipioSchema=new mongoose.Schema(
    {
        CUN: String,
        CPRO: String,
        CMUM: String,
        DMUN50: String
    }
);

module.exports= mongoose.model("Municipio", municipioSchema, "municipios")