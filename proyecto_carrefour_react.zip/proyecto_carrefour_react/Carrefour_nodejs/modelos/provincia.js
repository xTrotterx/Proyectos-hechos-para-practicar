const mongoose = require("mongoose");

const provinciaSchema=new mongoose.Schema(
    {
        CPRO: String,
        PRO: String,
        CCOM: String
    }
);

module.exports=mongoose.model("Provincia", provinciaSchema, "provincias")