require('dotenv').config(); //<---- el metodo .config() del objeto importado desde require('dotenv'), lee fichero .env
                            // en directorio raiz del proyecto...
const express=require('express');
const configpipeline=require('./config_server/config_pipeline');

const app=express();
//console.log('el valor de express importado desde el require("express") vale...', express);
//console.log('el valor que devuelve la ejecucion de dicha funcion: express y q se almacena en app vale...', app);

configpipeline(app);


app.listen(3003, (error)=>{
    if(!error) console.log('....servidor web express a la escucha en puerto 3003.... ')
})