const axios=import('axios');

module.exports={
    EnviarEmail: async ( to, subject, body, htmlbody )=>{
        try {
            
        } catch (error) {
            
        }
    }

}